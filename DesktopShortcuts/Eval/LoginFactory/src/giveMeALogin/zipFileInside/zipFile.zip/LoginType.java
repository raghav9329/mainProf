package giveMeALogin;
public enum LoginType { FIREFOX, CHROME, UNDEFINED, WEEJUN }