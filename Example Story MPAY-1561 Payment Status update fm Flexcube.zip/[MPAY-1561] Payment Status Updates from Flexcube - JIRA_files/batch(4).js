;
/* module-key = 'com.atlassian.auiplugin:aui-experimental-expander', location = 'js/aui-experimental-expander.js' */
(function(D){var E=D(document),C=function(G){var F={};F.$trigger=D(G.currentTarget);F.$content=E.find("#"+F.$trigger.attr("aria-controls"));F.triggerIsParent=F.$content.parent().filter(F.$trigger).length!==0;F.$shortContent=F.triggerIsParent?F.$trigger.find(".aui-expander-short-content"):null;F.height=F.$content.css("min-height");F.isCollapsible=F.$trigger.data("collapsible")!==false;F.replaceText=F.$trigger.attr("data-replace-text");F.replaceSelector=F.$trigger.data("replace-selector");return F},B=function(G){if(G.replaceText){var F=G.replaceSelector?G.$trigger.find(G.replaceSelector):G.$trigger;G.$trigger.attr("data-replace-text",F.text());F.text(G.replaceText)}};var A={"aui-expander-invoke":function(I){var F=D(I.currentTarget);var H=E.find("#"+F.attr("aria-controls"));var G=F.data("collapsible")!==false;if(H.attr("aria-expanded")==="true"&&G){F.trigger("aui-expander-collapse")}else{F.trigger("aui-expander-expand")}},"aui-expander-expand":function(G){var F=C(G);F.$content.attr("aria-expanded","true");F.$trigger.attr("aria-expanded","true");if(F.$content.outerHeight()>0){F.$content.attr("aria-hidden","false")}B(F);if(F.triggerIsParent){F.$shortContent.hide()}F.$trigger.trigger("aui-expander-expanded")},"aui-expander-collapse":function(G){var F=C(G);B(F);F.$content.attr("aria-expanded","false");F.$trigger.attr("aria-expanded","false");if(F.triggerIsParent){F.$shortContent.show()}if(F.$content.outerHeight()===0){F.$content.attr("aria-hidden","true")}F.$trigger.trigger("aui-expander-collapsed")},"click.aui-expander":function(G){var F=D(G.currentTarget);F.trigger("aui-expander-invoke",G.currentTarget)}};E.on(A,".aui-expander-trigger")})(jQuery);;
;
/* module-key = 'com.atlassian.jira.plugins.jira-transition-triggers-plugin:dev-status-common-resources', location = 'js/workflow/TriggersPluginBackboneDefine.js' */
if(Backbone&&!Backbone.define){Backbone.define=function(name,ctor){eval("Backbone['Class: "+name+"'] = function() { Backbone['Class: "+name+"'].__ctor.apply(this, arguments); }");var cls=Backbone["Class: "+name];cls.__ctor=ctor;ctor.prototype.name=name;cls.prototype=ctor.prototype;_.extend(cls,ctor);_.each(ctor.prototype,function(fn,fnName){if(typeof fn==="function"){fn.displayName=name+"."+fnName}});var context=window;var parts=name.split(".");_.each(parts,function(part,i){if(i===parts.length-1){context[part]=cls}else{context=context[part]==null?(context[part]={}):context[part]}});return cls}};;
;
/* module-key = 'com.atlassian.jira.plugins.jira-transition-triggers-plugin:dev-status-common-resources', location = 'js/devstatus/FeedbackDialog.js' */
Backbone.define("JIRA.DevStatus.FeedbackDialog",Backbone.Model.extend({properties:["collectorId","summary"],defaults:{summary:"Tell us what you think.",collectorId:"effe8b72"},show:function(){var a=this.get("collectorId");window.ATL_JQ_PAGE_PROPS=window.ATL_JQ_PAGE_PROPS||{};window.ATL_JQ_PAGE_PROPS[a]={fieldValues:{summary:this.get("summary")},triggerFunction:function(b){_.defer(function(){b()})}};AJS.$.getScript(this._collectorUrlFor(a))},_collectorUrlFor:function(a){return"https://jira.atlassian.com/s/d41d8cd98f00b204e9800998ecf8427e/en_UK-7m3tmj-1988229788/6307/131/1.4.8/_/download/batch/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector.js?collectorId="+a}}));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-frame-resources', location = 'templates/common/devstatus-detail-dialog-frame.soy' */
// This file was automatically generated from devstatus-detail-dialog-frame.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialogFrame.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialogFrame == 'undefined') { JIRA.Templates.DevStatus.DetailDialogFrame = {}; }


JIRA.Templates.DevStatus.DetailDialogFrame.frame = function(opt_data, opt_ignored) {
  return '<div class="jira-dialog-heading devstatus-dialog-heading ' + ((opt_data.tabs.length > 1) ? 'borderless' : '') + '"><h2>' + soy.$$escapeHtml(opt_data.title) + '</h2></div><div class="jira-dialog-content devstatus-dialog-content">' + JIRA.Templates.DevStatus.DetailDialogFrame.applicationTabs(opt_data) + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialogFrame.frame.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialogFrame.frame';
}


JIRA.Templates.DevStatus.DetailDialogFrame.applicationTabs = function(opt_data, opt_ignored) {
  var output = '<div class="aui-tabs horizontal-tabs"><ul class="tabs-menu ' + ((opt_data.tabs.length == 1) ? 'hidden' : '') + '" >';
  var tabList18 = opt_data.tabs;
  var tabListLen18 = tabList18.length;
  for (var tabIndex18 = 0; tabIndex18 < tabListLen18; tabIndex18++) {
    var tabData18 = tabList18[tabIndex18];
    output += '<li id="tab-menu-' + soy.$$escapeHtml(tabData18.type) + '" data-application-type=' + soy.$$escapeHtml(tabData18.type) + ' class="menu-item ' + ((! opt_data.initialTab && tabIndex18 == 0 || tabData18.type == opt_data.initialTab) ? ' active-tab' : '') + '"><a  href="#tab-content-' + soy.$$escapeHtml(tabData18.type) + '"><strong>' + soy.$$escapeHtml(tabData18.name) + '</strong><span class="aui-badge devstatus-tab-count">' + soy.$$escapeHtml(tabData18.count) + '</span></a></li>';
  }
  output += '</ul><div class="form-body">';
  var tabList36 = opt_data.tabs;
  var tabListLen36 = tabList36.length;
  for (var tabIndex36 = 0; tabIndex36 < tabListLen36; tabIndex36++) {
    var tabData36 = tabList36[tabIndex36];
    output += '<div class="tabs-pane ' + ((tabIndex36 == 0) ? 'active-pane' : '') + '" id="tab-content-' + soy.$$escapeHtml(tabData36.type) + '"><div class="status-loading"></div><div class="detail-content-container"></div></div>';
  }
  output += '</div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialogFrame.applicationTabs.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialogFrame.applicationTabs';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/devstatus-detail-dialog.soy' */
// This file was automatically generated from devstatus-detail-dialog.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }


JIRA.Templates.DevStatus.DetailDialog.repositoryHeader = function(opt_data, opt_ignored) {
  return '<div class="repository-header' + ((opt_data.extraClasses) ? ' ' + soy.$$escapeHtml(opt_data.extraClasses) : '') + '"><div class="aui-group aui-group-split repository-header-group"><div class="aui-item project-space">' + JIRA.Templates.DevStatus.DetailDialog.projectInfo(opt_data) + '</div>' + ((opt_data.extraContent) ? '<div class="aui-item action-space">' + soy.$$filterNoAutoescape(opt_data.extraContent) + '</div>' : '') + '</div></div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.repositoryHeader.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.repositoryHeader';
}


JIRA.Templates.DevStatus.DetailDialog.projectInfo = function(opt_data, opt_ignored) {
  return '<div class="project-avatar" ' + ((opt_data.repository.avatarDescription) ? 'title="' + soy.$$escapeHtml(opt_data.repository.avatarDescription) + '"' : '') + '><span class="aui-avatar aui-avatar-small aui-avatar-project ' + ((opt_data.repository.avatar) ? 'fusion-avatar-project' : 'default-avatar-project') + '">' + ((opt_data.repository.avatar) ? '<span class="aui-avatar-inner"><img src="' + soy.$$escapeHtml(opt_data.repository.avatar) + '" /></span>' : '<span class="aui-avatar-inner aui-icon aui-icon-small aui-iconfont-devtools-repository"></span>') + '</span></div><div class="project-info">' + ((opt_data.repository.url) ? '<a class="repository-link" href="' + soy.$$escapeHtml(opt_data.repository.url) + '"' + ((opt_data.showTooltip) ? ' title="' + soy.$$escapeHtml(opt_data.repository.name) + '"' : '') + '>' + soy.$$escapeHtml(opt_data.repository.name) + '</a>' : '<span class="repository-link" ' + ((opt_data.showTooltip) ? ' title="' + soy.$$escapeHtml(opt_data.repository.name) + '"' : '') + '>' + soy.$$escapeHtml(opt_data.repository.name) + '</span>') + '</div><div class="extra-project-info">' + ((opt_data.showParent && opt_data.repository.parent && opt_data.repository.parent.name && opt_data.repository.parent.url) ? '<a class="fork-off" href="' + soy.$$escapeHtml(opt_data.repository.parent.url) + '"><span class="fork-name" title="' + soy.$$escapeHtml(AJS.format("Fork of {0}",opt_data.repository.parent.name)) + '">' + soy.$$escapeHtml(AJS.format("Fork of {0}",opt_data.repository.parent.name)) + '</span></a>' : '') + ((opt_data.extraProjectInfo) ? soy.$$filterNoAutoescape(opt_data.extraProjectInfo) : '') + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.projectInfo.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.projectInfo';
}


JIRA.Templates.DevStatus.DetailDialog.oauthStatus = function(opt_data, opt_ignored) {
  return '<span class="aui-icon aui-icon-small aui-iconfont-info" /> ' + soy.$$escapeHtml(opt_data.message) + ' ';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.oauthStatus.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.oauthStatus';
}


JIRA.Templates.DevStatus.DetailDialog.authenticationScreen = function(opt_data, opt_ignored) {
  return '<div class="authentication-problem"><div class="image"></div><h2>' + soy.$$escapeHtml(opt_data.title) + '</h2>' + ((opt_data.userError) ? '<p class="user-error">' + soy.$$escapeHtml(opt_data.userError) + '</p>' : '') + ((opt_data.unauthInstances.length > 0) ? '<p>' + soy.$$escapeHtml(AJS.format("Please log in to approve {0,choice,1#this application|1\x3cthese applications}:",opt_data.unauthInstances.length)) + ' <span class="instances"></span></p>' : '') + ((opt_data.otherInstances.length > 0) ? JIRA.Templates.DevStatus.connectionProblemAsWarning({instances: opt_data.otherInstances, showContactAdminForm: opt_data.showContactAdminForm}) : '') + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.authenticationScreen.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.authenticationScreen';
}


JIRA.Templates.DevStatus.DetailDialog.connectionProblemScreen = function(opt_data, opt_ignored) {
  return '<div class="connection-problem"><div class="image"></div><h2>' + soy.$$escapeHtml(opt_data.title) + '</h2>' + JIRA.Templates.DevStatus.connectionProblem(opt_data) + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.connectionProblemScreen.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.connectionProblemScreen';
}


JIRA.Templates.DevStatus.DetailDialog.noPermissionToViewAll = function(opt_data, opt_ignored) {
  return '<div class="no-permission-to-view-all"><div class="lock-image"></div><span>' + soy.$$escapeHtml(opt_data.message) + '</span>' + ((opt_data.secondaryMessage) ? ' <span>' + soy.$$escapeHtml(opt_data.secondaryMessage) + '</span>' : '') + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.noPermissionToViewAll.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.noPermissionToViewAll';
}


JIRA.Templates.DevStatus.DetailDialog.timestamp = function(opt_data, opt_ignored) {
  return '' + ((opt_data.timestamp) ? '<time class="livestamp date user-tz" datetime="' + soy.$$escapeHtml(opt_data.timestamp) + '" data-datetime-format="longAge">' + soy.$$escapeHtml(opt_data.timestamp) + '</time>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.timestamp.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.timestamp';
}


JIRA.Templates.DevStatus.DetailDialog.vcsUser = function(opt_data, opt_ignored) {
  return '<span><div class="vcs-user"><span class="extra-content-in-title ' + ((opt_data.approved) ? 'fade' : '') + '" title="' + soy.$$escapeHtml(opt_data.name) + '"><img class="author-avatar" src="' + soy.$$escapeHtml(opt_data.avatar) + '"/></span>' + ((opt_data.approved) ? '<span class="approved">\u2713</span>' : '') + '</div></span>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.vcsUser.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.vcsUser';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/build/devstatus-detail-dialog-build.soy' */
// This file was automatically generated from devstatus-detail-dialog-build.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }


JIRA.Templates.DevStatus.DetailDialog.build = function(opt_data, opt_ignored) {
  var output = '';
  var projectList3 = opt_data.projects;
  var projectListLen3 = projectList3.length;
  for (var projectIndex3 = 0; projectIndex3 < projectListLen3; projectIndex3++) {
    var projectData3 = projectList3[projectIndex3];
    output += JIRA.Templates.DevStatus.DetailDialog.projectContent({project: projectData3, projectIndex: projectIndex3, withArtifactColumn: opt_data.hasArtifacts, applicationType: opt_data.applicationType});
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.build.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.build';
}


JIRA.Templates.DevStatus.DetailDialog.projectContent = function(opt_data, opt_ignored) {
  var output = '<div class="detail-builds-container">' + JIRA.Templates.DevStatus.DetailDialog.projectHeader(opt_data) + '<div class="devstatus-detail-table builds-table' + ((opt_data.withArtifactColumn) ? ' builds-table-with-artifact-column' : '') + '"><table class="aui"><thead><tr><th class="plan">' + soy.$$escapeHtml("Plan") + '</th><th class="build cell-type-collapsed">' + soy.$$escapeHtml("Latest build") + '</th><th class="result cell-type-collapsed">' + soy.$$escapeHtml("Result") + '</th><th class="timestamp cell-type-collapsed">' + soy.$$escapeHtml("Completed") + '</th>' + ((opt_data.withArtifactColumn) ? '<th class="actions cell-type-collapsed"></th>' : '') + '</tr></thead><tbody>';
  var planList30 = opt_data.project.plans;
  var planListLen30 = planList30.length;
  for (var planIndex30 = 0; planIndex30 < planListLen30; planIndex30++) {
    var planData30 = planList30[planIndex30];
    var planHasArtifacts__soy31 = planData30.build.artifacts && planData30.build.artifacts.length;
    var uniqueIdSuffix__soy32 = opt_data.projectIndex + '-' + planIndex30;
    output += '<tr class="plan-row' + ((planHasArtifacts__soy31) ? ' merge' : '') + '"><td class="plan">' + JIRA.Templates.DevStatus.DetailDialog.planName({plan: planData30}) + '</td><td class="build">' + JIRA.Templates.DevStatus.DetailDialog.buildIcon({build: planData30.build}) + ' <a class="build-link" href="' + soy.$$escapeHtml(planData30.build.url) + '">' + soy.$$escapeHtml(AJS.format("#{0}",planData30.build.buildNumber)) + '</a></td><td class="result">' + JIRA.Templates.DevStatus.DetailDialog.buildResult({build: planData30.build}) + '</td><td class="timestamp">' + JIRA.Templates.DevStatus.DetailDialog.timestamp({timestamp: planData30.build.finishedDate}) + '</td>' + ((opt_data.withArtifactColumn) ? '<td class="actions">' + ((planHasArtifacts__soy31) ? aui.expander.trigger({id: 'detail-dialog-build-show-artifacts-trigger-' + uniqueIdSuffix__soy32, contentId: 'detail-dialog-build-show-artifacts-content-' + uniqueIdSuffix__soy32, tag: 'a', content: "Show artifacts", replaceText: "Hide artifacts"}) : '') + '</td>' : '') + '</tr>' + ((planHasArtifacts__soy31) ? '<tr class="artifacts"><td colspan="5">' + aui.expander.content({id: 'detail-dialog-build-show-artifacts-content-' + uniqueIdSuffix__soy32, content: '' + JIRA.Templates.DevStatus.DetailDialog.artifactsTable({build: planData30.build})}) + '</td></tr>' : '');
  }
  output += '</tbody></table></div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.projectContent.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.projectContent';
}


JIRA.Templates.DevStatus.DetailDialog.projectHeader = function(opt_data, opt_ignored) {
  return '<div class="builds-header"><div class="project-info"><h2 class="ellipsis"><a class="project-link" href="' + soy.$$escapeHtml(opt_data.project.url) + '" title="' + soy.$$escapeHtml(opt_data.project.name) + '">' + soy.$$escapeHtml(opt_data.project.name) + '</a></h2></div></div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.projectHeader.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.projectHeader';
}


JIRA.Templates.DevStatus.DetailDialog.planName = function(opt_data, opt_ignored) {
  return '<div><span class="plan-name">' + ((opt_data.plan.isBranch) ? '<a class="plan-link" href="' + soy.$$escapeHtml(opt_data.plan.url) + '" title="' + soy.$$escapeHtml(opt_data.plan.name) + ' &rsaquo; ' + soy.$$escapeHtml(opt_data.plan.branchName) + '">' + soy.$$escapeHtml(opt_data.plan.name) + '</a> &rsaquo; <span class="aui-icon aui-icon-small aui-iconfont-devtools-branch-small">' + soy.$$escapeHtml(opt_data.plan.branchName) + '</span><a class="plan-link" href="' + soy.$$escapeHtml(opt_data.plan.url) + '" title="' + soy.$$escapeHtml(opt_data.plan.name) + ' &rsaquo; ' + soy.$$escapeHtml(opt_data.plan.branchName) + '">' + soy.$$escapeHtml(opt_data.plan.branchName) + '</a>' : '<a class="plan-link" href="' + soy.$$escapeHtml(opt_data.plan.url) + '" title="' + soy.$$escapeHtml(opt_data.plan.name) + '">' + soy.$$escapeHtml(opt_data.plan.name) + '</a>') + '</span>' + ((opt_data.plan.disabled) ? '<span class="aui-lozenge aui-lozenge-subtle disabled" title="' + soy.$$escapeHtml("This plan is disabled") + '">' + soy.$$escapeHtml("Disabled") + '</span>' : '') + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.planName.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.planName';
}


JIRA.Templates.DevStatus.DetailDialog.buildResult = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.build.buildState == 'SUCCESS' || opt_data.build.buildState == 'FAILED') {
    if (opt_data.build.testSummary) {
      var duration__soy131 = '' + JIRA.Templates.DevStatus.DetailDialog.buildDuration(opt_data);
      output += '<span>' + ((opt_data.build.testSummary.failedTestCount > 0) ? (opt_data.build.testSummary.successfulTestCount) ? soy.$$escapeHtml(AJS.format("{0} of {1} tests failed in {2}",opt_data.build.testSummary.failedTestCount,opt_data.build.testSummary.totalTestCount,duration__soy131)) : soy.$$escapeHtml(AJS.format("{0} {0,choice,1#test|1\x3ctests} failed in {1}",opt_data.build.testSummary.failedTestCount,duration__soy131)) : (opt_data.build.testSummary.successfulTestCount > 0) ? soy.$$escapeHtml(AJS.format("{0} {0,choice,1#test|1\x3ctests} passed in {1}",opt_data.build.testSummary.successfulTestCount,duration__soy131)) : (opt_data.build.buildState == 'SUCCESS') ? soy.$$escapeHtml(AJS.format("Passed in {0}",duration__soy131)) : soy.$$escapeHtml(AJS.format("Failed in {0}",duration__soy131))) + '</span>';
    }
  } else {
    output += soy.$$escapeHtml("Build incomplete");
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.buildResult.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.buildResult';
}


JIRA.Templates.DevStatus.DetailDialog.buildDuration = function(opt_data, opt_ignored) {
  return '' + ((opt_data.build) ? (opt_data.build.durationInSeconds < 1) ? soy.$$escapeHtml("under 1 second") : (opt_data.build.durationInSeconds < 90) ? soy.$$escapeHtml(AJS.format("{0} {0,choice,1#second|1\x3cseconds}",opt_data.build.durationInSeconds)) : (opt_data.build.durationInSeconds < 5400) ? soy.$$escapeHtml(AJS.format("{0} {0,choice,1#minute|1\x3cminutes}",Math.floor(opt_data.build.durationInSeconds / 60))) : soy.$$escapeHtml(AJS.format("{0} {0,choice,1#hour|1\x3chours}",Math.floor(opt_data.build.durationInSeconds / 60 / 60))) : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.buildDuration.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.buildDuration';
}


JIRA.Templates.DevStatus.DetailDialog.buildIcon = function(opt_data, opt_ignored) {
  var output = '';
  var iconClass__soy167 = '' + ((opt_data.build.buildState == 'SUCCESS') ? 'aui-iconfont-approve' : (opt_data.build.buildState == 'FAILED') ? 'aui-iconfont-error' : 'aui-iconfont-devtools-task-cancelled');
  output += '<span class="aui-icon aui-icon-small ' + soy.$$escapeHtml(iconClass__soy167) + '">' + soy.$$escapeHtml(opt_data.build.buildState) + '</span>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.buildIcon.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.buildIcon';
}


JIRA.Templates.DevStatus.DetailDialog.artifactsTable = function(opt_data, opt_ignored) {
  var output = '';
  var column1Height__soy181 = Math.ceil(opt_data.build.artifacts.length / 3);
  var column2Height__soy182 = Math.ceil((opt_data.build.artifacts.length - 1) / 3);
  var column3Height__soy183 = Math.ceil((opt_data.build.artifacts.length - 2) / 3);
  output += '<div class="build-artifacts-table"><table class="aui"><tbody>';
  var artifactIndexLimit185 = column1Height__soy181;
  for (var artifactIndex185 = 0; artifactIndex185 < artifactIndexLimit185; artifactIndex185++) {
    output += '<tr><td>' + JIRA.Templates.DevStatus.DetailDialog.artifactName({artifact: opt_data.build.artifacts[artifactIndex185]}) + '</td><td>' + ((artifactIndex185 < column2Height__soy182) ? JIRA.Templates.DevStatus.DetailDialog.artifactName({artifact: opt_data.build.artifacts[artifactIndex185 + column1Height__soy181]}) : '') + '</td><td>' + ((artifactIndex185 < column3Height__soy183) ? JIRA.Templates.DevStatus.DetailDialog.artifactName({artifact: opt_data.build.artifacts[artifactIndex185 + column1Height__soy181 + column2Height__soy182]}) : '') + '</td></tr>';
  }
  output += '</tbody></table></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.artifactsTable.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.artifactsTable';
}


JIRA.Templates.DevStatus.DetailDialog.artifactName = function(opt_data, opt_ignored) {
  return '' + ((opt_data.artifact && opt_data.artifact.name) ? (opt_data.artifact.url) ? '<a class="artifact-link" href="' + soy.$$escapeHtml(opt_data.artifact.url) + '">' + soy.$$escapeHtml(opt_data.artifact.name) + '</a>' : soy.$$escapeHtml(opt_data.artifact.name) : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.artifactName.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.artifactName';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/deployment/devstatus-detail-dialog-deployment.soy' */
// This file was automatically generated from devstatus-detail-dialog-deployment.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.Deployment.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog.Deployment == 'undefined') { JIRA.Templates.DevStatus.DetailDialog.Deployment = {}; }


JIRA.Templates.DevStatus.DetailDialog.Deployment.deployment = function(opt_data, opt_ignored) {
  var output = '';
  var projectList3 = opt_data.deploymentProjects;
  var projectListLen3 = projectList3.length;
  for (var projectIndex3 = 0; projectIndex3 < projectListLen3; projectIndex3++) {
    var projectData3 = projectList3[projectIndex3];
    output += JIRA.Templates.DevStatus.DetailDialog.Deployment.projectContent({project: projectData3, applicationType: opt_data.applicationType});
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Deployment.deployment.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Deployment.deployment';
}


JIRA.Templates.DevStatus.DetailDialog.Deployment.projectContent = function(opt_data, opt_ignored) {
  var output = '<div class="detail-deployments-container">' + JIRA.Templates.DevStatus.DetailDialog.Deployment.projectHeader(opt_data) + '<div class="devstatus-detail-table deployments-table"><table class="aui"><thead><tr><th class="environment">' + soy.$$escapeHtml("Environment") + '</th><th class="status cell-type-collapsed">' + soy.$$escapeHtml("Status") + '</th><th class="release cell-type-collapsed">' + soy.$$escapeHtml("Latest release") + '</th><th class="timestamp cell-type-collapsed">' + soy.$$escapeHtml("Last deployed") + '</th></tr></thead><tbody>';
  var environmentList20 = opt_data.project.environments;
  var environmentListLen20 = environmentList20.length;
  for (var environmentIndex20 = 0; environmentIndex20 < environmentListLen20; environmentIndex20++) {
    var environmentData20 = environmentList20[environmentIndex20];
    output += '<tr class="environment-row"><td class="environment">' + JIRA.Templates.DevStatus.DetailDialog.Deployment.environmentName({environment: environmentData20}) + '</td><td class="status cell-type-collapsed">' + JIRA.Templates.DevStatus.DetailDialog.Deployment.statusLozenge({environment: environmentData20}) + '</td><td class="release">' + ((environmentData20.deployedVersion) ? JIRA.Templates.DevStatus.DetailDialog.Deployment.release({release: environmentData20.deployedVersion}) : '') + '</td><td class="timestamp">' + JIRA.Templates.DevStatus.DetailDialog.timestamp({timestamp: environmentData20.lastDeployed}) + '</td></tr>';
  }
  output += '</tbody></table></div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Deployment.projectContent.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Deployment.projectContent';
}


JIRA.Templates.DevStatus.DetailDialog.Deployment.projectHeader = function(opt_data, opt_ignored) {
  return '<div class="deployments-header"><div class="project-info"><h2 class="ellipsis"><a class="project-link" href="' + soy.$$escapeHtml(opt_data.project.url) + '" title="' + ((opt_data.project.description) ? soy.$$escapeHtml(opt_data.project.description) : soy.$$escapeHtml(opt_data.project.name)) + '">' + soy.$$escapeHtml(opt_data.project.name) + '</a></h2><div class="ellipsis"><strong class="commit-info">' + soy.$$escapeHtml(AJS.format("Commits were in release {0}",opt_data.project.latestVersions[0].name)) + '</strong></div></div></div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Deployment.projectHeader.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Deployment.projectHeader';
}


JIRA.Templates.DevStatus.DetailDialog.Deployment.environmentName = function(opt_data, opt_ignored) {
  return '<a class="environment-link" href="' + soy.$$escapeHtml(opt_data.environment.url) + '" title="' + ((opt_data.environment.description) ? soy.$$escapeHtml(opt_data.environment.description) : soy.$$escapeHtml(opt_data.environment.name)) + '">' + soy.$$escapeHtml(opt_data.environment.name) + '</a>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Deployment.environmentName.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Deployment.environmentName';
}


JIRA.Templates.DevStatus.DetailDialog.Deployment.statusLozenge = function(opt_data, opt_ignored) {
  return '' + ((opt_data.environment.status == 'DEPLOYED') ? '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-success">' + soy.$$escapeHtml("Deployed") + '</span>' : (opt_data.environment.status == 'FAILED') ? '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-error">' + soy.$$escapeHtml("Failed") + '</span>' : (opt_data.environment.status == 'NOT_DEPLOYED') ? '<span class="aui-lozenge aui-lozenge-subtle">' + soy.$$escapeHtml("Not deployed") + '</span>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Deployment.statusLozenge.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Deployment.statusLozenge';
}


JIRA.Templates.DevStatus.DetailDialog.Deployment.release = function(opt_data, opt_ignored) {
  return '' + ((opt_data.release.url) ? '<a class="release-link" href="' + soy.$$escapeHtml(opt_data.release.url) + '" title="' + soy.$$escapeHtml(opt_data.release.name) + '">' + soy.$$escapeHtml(opt_data.release.name) + '</a>' : soy.$$escapeHtml(opt_data.release.name));
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Deployment.release.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Deployment.release';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/devstatus-detail-dialog-commit.soy' */
// This file was automatically generated from devstatus-detail-dialog-commit.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }


JIRA.Templates.DevStatus.DetailDialog.commit = function(opt_data, opt_ignored) {
  var output = '' + ((opt_data.canCreateReview) ? '<div class="aui-group aui-group-split"><div class="aui-item"></div><div class="aui-item"><div class="create-review-instance"><a href="#">' + soy.$$escapeHtml("Create review for all commits") + '</a></div></div></div>' : '');
  var repoList8 = opt_data.repositories;
  var repoListLen8 = repoList8.length;
  for (var repoIndex8 = 0; repoIndex8 < repoListLen8; repoIndex8++) {
    var repoData8 = repoList8[repoIndex8];
    output += JIRA.Templates.DevStatus.DetailDialog.commitContent(soy.$$augmentMap(opt_data, {repository: repoData8, repositoryIndex: repoIndex8}));
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.commit.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.commit';
}


JIRA.Templates.DevStatus.DetailDialog.commitContent = function(opt_data, opt_ignored) {
  var output = '<div class="detail-commits-container' + ((opt_data.repository.showReviews) ? ' has-reviews' : '') + ((opt_data.repository.showBranches) ? ' has-branches' : '') + ((opt_data.repository.showFiles) ? ' has-files' : '') + ' ' + ((opt_data.repository.showCreateReview) ? 'has-actions' : '') + '" data-repository-index="' + soy.$$escapeHtml(opt_data.repositoryIndex) + '" >' + JIRA.Templates.DevStatus.DetailDialog.repositoryHeader(soy.$$augmentMap(opt_data, {showParent: true, extraProjectInfo: '' + ((opt_data.repository.showInstance && opt_data.repository.instance) ? '<div class="repository-instance" title="' + soy.$$escapeHtml(opt_data.repository.instance.name) + '">(' + soy.$$escapeHtml(opt_data.repository.instance.name) + ')</div>' : ''), extraContent: '' + ((opt_data.repository.showFiles) ? '<div class="file-expand"><a href="#">' + soy.$$escapeHtml("Show all files") + '</a></div>' : '')})) + '<div class="devstatus-detail-table commits-table"><table class="aui"><thead><tr><th class="author cell-type-collapsed">' + soy.$$escapeHtml("Author") + '</th><th class="changeset cell-type-collapsed">' + soy.$$escapeHtml("Commit") + '</th><th class="message">' + soy.$$escapeHtml("Message") + '</th>' + ((opt_data.repository.showBranches) ? '<th class="branches"></th>' : '') + ((opt_data.repository.showReviews) ? '<th class="reviews">' + soy.$$escapeHtml("Reviews") + '</th>' : '') + '<th class="timestamp">' + soy.$$escapeHtml("Date") + '</th>' + ((opt_data.repository.showFiles) ? '<th class="filecount">' + soy.$$escapeHtml("Files") + '</th>' : '') + ((opt_data.repository.showCreateReview) ? '<th class="commit-actions">' + soy.$$escapeHtml("Actions") + '</th>' : '') + '</tr></thead><tbody>';
  var commitList76 = opt_data.repository.commits;
  var commitListLen76 = commitList76.length;
  for (var commitIndex76 = 0; commitIndex76 < commitListLen76; commitIndex76++) {
    var commitData76 = commitList76[commitIndex76];
    output += '<tr data-changesetid="' + soy.$$escapeHtml(commitData76.id) + '" class="commitrow' + ((commitData76.merge) ? ' merge' : '') + '" data-commit-index="' + soy.$$escapeHtml(commitIndex76) + '"><td class="author">' + JIRA.Templates.DevStatus.DetailDialog.vcsUser(commitData76.author) + '</td><td class="changeset">' + ((commitData76.url) ? '<a class="changesetid" href="' + soy.$$escapeHtml(commitData76.url) + '">' + soy.$$escapeHtml(commitData76.displayId) + '</a>' : '<span class="changesetid">' + soy.$$escapeHtml(commitData76.displayId) + '</span>') + ((commitData76.merge) ? JIRA.Templates.DevStatus.DetailDialog.mergeLozenge(null) : '') + '</td><td class="message"><span class="ellipsis" title="' + soy.$$escapeHtml(commitData76.message) + '">' + soy.$$truncate(soy.$$escapeHtml(commitData76.message), 500, true) + '</span></td>' + JIRA.Templates.DevStatus.DetailDialog.branchesColumn(soy.$$augmentMap(opt_data, {commit: commitData76})) + JIRA.Templates.DevStatus.DetailDialog.reviewColumn(soy.$$augmentMap(opt_data, {commit: commitData76})) + '<td class="timestamp"><time class="livestamp" datetime="' + soy.$$escapeHtml(commitData76.authorTimestamp) + '" data-datetime-format="longAge"> ' + soy.$$escapeHtml(commitData76.authorTimestamp) + '</time></td>' + ((opt_data.repository.showFiles) ? JIRA.Templates.DevStatus.DetailDialog.filesColumn({count: commitData76.fileCount}) : '') + ((opt_data.repository.showCreateReview) ? JIRA.Templates.DevStatus.DetailDialog.actionsColumn(soy.$$augmentMap(opt_data, {commit: commitData76})) : '') + '</tr>' + ((opt_data.repository.showFiles) ? JIRA.Templates.DevStatus.DetailDialog.filesRow(soy.$$augmentMap(opt_data, {repository: opt_data.repository, commit: commitData76})) : '');
  }
  output += '</tbody></table></div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.commitContent.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.commitContent';
}


JIRA.Templates.DevStatus.DetailDialog.mergeLozenge = function(opt_data, opt_ignored) {
  return '<span class="aui-lozenge merge" title="' + soy.$$escapeHtml("This commit is a merge") + '">' + soy.$$escapeHtml("M") + '</span>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.mergeLozenge.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.mergeLozenge';
}


JIRA.Templates.DevStatus.DetailDialog.branchesColumn = function(opt_data, opt_ignored) {
  return '' + ((opt_data.repository.showBranches) ? '<td class="branches">' + ((opt_data.commit.branches && opt_data.commit.branches.totalCount > 0) ? '<span class="branches-link aui-lozenge ref-lozenge"><span class="aui-icon aui-icon-small aui-iconfont-devtools-branch-small">Branch</span></button>' + ((opt_data.commit.branches.totalCount > 1) ? '<span class="branch-count">' + soy.$$escapeHtml(opt_data.commit.branches.totalCount) + '</span>' : '') + '</span>' : '') + '</td>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.branchesColumn.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.branchesColumn';
}


JIRA.Templates.DevStatus.DetailDialog.branchesTooltip = function(opt_data, opt_ignored) {
  var output = '<span class="branch-tooltip">';
  var branchList155 = opt_data.branchData.branches;
  var branchListLen155 = branchList155.length;
  for (var branchIndex155 = 0; branchIndex155 < branchListLen155; branchIndex155++) {
    var branchData155 = branchList155[branchIndex155];
    output += '<div class="branch-name-tooltip">' + soy.$$escapeHtml(branchData155.name) + '</div>';
  }
  output += ((opt_data.branchData.totalCount > opt_data.branchData.branches.length) ? '<div class="branch-tooltip-summary">' + soy.$$escapeHtml(AJS.format("and {0} more",opt_data.branchData.totalCount - opt_data.branchData.branches.length)) + '</div>' : '') + '</span>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.branchesTooltip.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.branchesTooltip';
}


JIRA.Templates.DevStatus.DetailDialog.reviewColumn = function(opt_data, opt_ignored) {
  return '' + ((opt_data.repository.showReviews) ? '<td class="reviews">' + ((opt_data.commit.reviews && opt_data.commit.reviews.totalCount > 0) ? '<a class="reviews-link">' + JIRA.Templates.FusionWidget.Common.reviewsStateViewIssue({state: opt_data.commit.reviews.reviews[0].state}) + '</a>' : '') + '</td>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.reviewColumn.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.reviewColumn';
}


JIRA.Templates.DevStatus.DetailDialog.actionsColumn = function(opt_data, opt_ignored) {
  return '<td class="commit-actions">' + ((opt_data.commit.createReviewUrl) ? '<div class="create-review-commit"><a href="' + soy.$$escapeHtml(opt_data.commit.createReviewUrl) + '">' + soy.$$escapeHtml("Create review") + '</a></div>' : '') + '</td>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.actionsColumn.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.actionsColumn';
}


JIRA.Templates.DevStatus.DetailDialog.filesColumn = function(opt_data, opt_ignored) {
  return '<td class="filecount">' + ((opt_data.count > 0) ? '<a href="#" class="extra-content-in-title" title="' + soy.$$escapeHtml("Click to show files") + '">' + ((opt_data.count < 100) ? soy.$$escapeHtml(AJS.format("{0} {0,choice,1#file|1\x3cfiles}",opt_data.count)) : soy.$$escapeHtml(AJS.format("{0}+ files",100))) + '</a>' : '') + '</td>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.filesColumn.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.filesColumn';
}


JIRA.Templates.DevStatus.DetailDialog.filesRow = function(opt_data, opt_ignored) {
  return '<tr class="hidden ' + soy.$$escapeHtml(opt_data.commit.fileCount > 0 && opt_data.commit.files ? 'filerow' : '') + '"><td colspan="5">' + JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileRow({files: opt_data.commit.files, max: 5}) + JIRA.Templates.DevStatus.DetailDialog.Commit.Files.moreFiles({files: opt_data.commit.files, fileCount: opt_data.commit.fileCount, instanceName: opt_data.repository.name, moreFilesUrl: opt_data.commit.url}) + '</td></tr>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.filesRow.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.filesRow';
}


JIRA.Templates.DevStatus.DetailDialog.reviewsInlineDialog = function(opt_data, opt_ignored) {
  var output = '<table><tbody>';
  var reviewList216 = opt_data.reviewData.reviews;
  var reviewListLen216 = reviewList216.length;
  for (var reviewIndex216 = 0; reviewIndex216 < reviewListLen216; reviewIndex216++) {
    var reviewData216 = reviewList216[reviewIndex216];
    output += '<tr class="inline-review-row"><td class="inline-review-id"><a href="' + soy.$$escapeHtml(reviewData216.url) + '">' + soy.$$escapeHtml(reviewData216.id) + '</a></td><td class="inline-review-state">' + JIRA.Templates.FusionWidget.Common.reviewsStateViewIssue({state: reviewData216.state}) + '</td></tr>';
  }
  output += ((opt_data.reviewData.totalCount > opt_data.reviewData.reviews.length) ? '<tr><td class="inline-review-summary" colspan="2">' + ((opt_data.reviewData.url) ? '<a href="' + soy.$$escapeHtml(opt_data.reviewData.url) + '">' + soy.$$escapeHtml(AJS.format("and {0} more",opt_data.reviewData.totalCount - opt_data.reviewData.reviews.length)) + '</a>' : '<span>' + soy.$$escapeHtml(AJS.format("and {0} more",opt_data.reviewData.totalCount - opt_data.reviewData.reviews.length)) + '</span>') + '</td></tr>' : '') + '</tbody></table>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.reviewsInlineDialog.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.reviewsInlineDialog';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/commit/devstatus-detail-dialog-commit-files.soy' */
// This file was automatically generated from devstatus-detail-dialog-commit-files.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.Commit.Files.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog.Commit == 'undefined') { JIRA.Templates.DevStatus.DetailDialog.Commit = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog.Commit.Files == 'undefined') { JIRA.Templates.DevStatus.DetailDialog.Commit.Files = {}; }


JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileRow = function(opt_data, opt_ignored) {
  var output = '';
  var fileList3 = opt_data.files;
  var fileListLen3 = fileList3.length;
  for (var fileIndex3 = 0; fileIndex3 < fileListLen3; fileIndex3++) {
    var fileData3 = fileList3[fileIndex3];
    output += (fileIndex3 < opt_data.max) ? '<div class="file"><div class="change">' + ((fileData3.linesAdded != null && fileData3.linesRemoved != null) ? '<div class="lines">' + ((fileData3.changeType == 'ADDED') ? '<span class="aui-lozenge added">' + soy.$$escapeHtml("Added") + '</span>' : (fileData3.changeType == 'DELETED') ? '<span class="aui-lozenge removed">' + soy.$$escapeHtml("Deleted") + '</span>' : '<span class="aui-lozenge added count">+' + soy.$$escapeHtml(fileData3.linesAdded) + '</span><span class="aui-lozenge removed count">-' + soy.$$escapeHtml(fileData3.linesRemoved) + '</span>') + '</div>' : '<div class="changetype">' + JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileChangeLozenge({changeType: fileData3.changeType}) + '</div>') + '</div><div class="filename ellipsis">' + ((fileData3.url) ? '<a href="' + soy.$$escapeHtml(fileData3.url) + '" title="' + soy.$$escapeHtml(fileData3.path) + '">' + soy.$$escapeHtml(fileData3.path) + '</a>' : soy.$$escapeHtml(fileData3.path)) + '</div></div>' : '';
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileRow.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileRow';
}


JIRA.Templates.DevStatus.DetailDialog.Commit.Files.moreFiles = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.files.length < opt_data.fileCount) {
    if (opt_data.moreFilesUrl) {
      output += '<a class="more-files-info" href="' + soy.$$escapeHtml(opt_data.moreFilesUrl) + '">' + soy.$$escapeHtml(AJS.format("See more files in {0}",opt_data.instanceName)) + '</a>';
    } else {
      var notShownFileCount__soy56 = opt_data.fileCount - opt_data.files.length;
      output += '<span class="more-files-info">' + soy.$$escapeHtml(AJS.format("and {0} more",notShownFileCount__soy56)) + '</span>';
    }
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Commit.Files.moreFiles.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Commit.Files.moreFiles';
}


JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileChangeLozenge = function(opt_data, opt_ignored) {
  var output = '';
  var text__soy61 = '';
  switch (opt_data.changeType) {
    case 'ADDED':
      text__soy61 += soy.$$escapeHtml("Added");
      break;
    case 'COPIED':
      text__soy61 += soy.$$escapeHtml("Copied");
      break;
    case 'DELETED':
      text__soy61 += soy.$$escapeHtml("Deleted");
      break;
    case 'MOVED':
      text__soy61 += soy.$$escapeHtml("Moved");
      break;
    default:
      text__soy61 += soy.$$escapeHtml("Modified");
  }
  var class__soy73 = '';
  switch (opt_data.changeType) {
    case 'ADDED':
      class__soy73 += 'success';
      break;
    case 'COPIED':
      class__soy73 += 'current';
      break;
    case 'DELETED':
      class__soy73 += 'error';
      break;
    case 'MOVED':
      class__soy73 += 'moved';
      break;
    default:
      class__soy73 += 'complete';
  }
  output += '<span class="aui-lozenge aui-lozenge-' + soy.$$escapeHtml(class__soy73) + ' aui-lozenge-subtle">' + soy.$$escapeHtml(text__soy61) + '</span>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileChangeLozenge.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.Commit.Files.fileChangeLozenge';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/devstatus-detail-dialog-branch-pullrequest.soy' */
// This file was automatically generated from devstatus-detail-dialog-branch-pullrequest.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }


JIRA.Templates.DevStatus.DetailDialog.pullRequest = function(opt_data, opt_ignored) {
  return '<div class="detail-pullrequests-container"><div class="devstatus-detail-table pullrequests-table"><table class="aui"><thead><tr><th class="pullrequest-id">' + soy.$$escapeHtml("ID") + '</th><th class="title">' + soy.$$escapeHtml("Title") + '</th><th class="state">' + soy.$$escapeHtml("Status") + '</th><th class="author">' + soy.$$escapeHtml("Author") + '</th><th class="reviewer">' + soy.$$escapeHtml("Reviewer") + '</th><th class="comment cell-type-collapsed"></th><th class="last-updated">' + soy.$$escapeHtml("Updated") + '</th></tr></thead><tbody>' + JIRA.Templates.DevStatus.DetailDialog.pullRequestEntry(opt_data) + '</tbody></table></div></div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.pullRequest.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.pullRequest';
}


JIRA.Templates.DevStatus.DetailDialog.pullRequestEntry = function(opt_data, opt_ignored) {
  var output = '';
  var pullRequestList19 = opt_data.pullRequests;
  var pullRequestListLen19 = pullRequestList19.length;
  for (var pullRequestIndex19 = 0; pullRequestIndex19 < pullRequestListLen19; pullRequestIndex19++) {
    var pullRequestData19 = pullRequestList19[pullRequestIndex19];
    output += '<tr class="pullrequest-row"><td class="pullrequest-id"><a class="pullrequest-link" href="' + soy.$$escapeHtml(pullRequestData19.url) + '">' + soy.$$escapeHtml(pullRequestData19.id) + '</a></td><td class="title"><a class="pullrequest-link ellipsis" title="' + soy.$$escapeHtml(pullRequestData19.name) + '" href="' + soy.$$escapeHtml(pullRequestData19.url) + '">' + soy.$$escapeHtml(pullRequestData19.name) + '</a></td><td class="state">' + JIRA.Templates.DevStatus.DetailDialog.pullRequestState({status: pullRequestData19.status, isSubtle: true}) + '</td><td class="author"><img class="author-avatar extra-content-in-title" src="' + soy.$$escapeHtml(pullRequestData19.author.avatar) + '" title="' + soy.$$escapeHtml(pullRequestData19.author.name) + '"/></td><td class="reviewer">' + ((pullRequestData19.reviewers && pullRequestData19.reviewers.length != 0) ? JIRA.Templates.DevStatus.DetailDialog.reviewersList(soy.$$augmentMap(pullRequestData19, {countThreshold: opt_data.reviewersThreshold})) : '') + '</td><td class="comment cell-type-collapsed">' + JIRA.Templates.DevStatus.DetailDialog.commentCount({pullRequest: pullRequestData19}) + '</td><td class="last-updated"><time class="livestamp" data-datetime-format="longAge" datetime="' + soy.$$escapeHtml(pullRequestData19.lastUpdate) + '">' + soy.$$escapeHtml(pullRequestData19.lastUpdate) + '</time></td></tr>';
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.pullRequestEntry.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.pullRequestEntry';
}


JIRA.Templates.DevStatus.DetailDialog.commentCount = function(opt_data, opt_ignored) {
  return '' + ((opt_data.pullRequest.commentCount) ? '<div class="comment-container"><a class="comment-link" href="' + soy.$$escapeHtml(opt_data.pullRequest.url) + '" title="' + soy.$$escapeHtml("Comments") + '"><span class="aui-icon aui-icon-small aui-iconfont-comment">Comments</span></a><span class="count">' + soy.$$escapeHtml(opt_data.pullRequest.commentCount) + '</span></div>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.commentCount.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.commentCount';
}


JIRA.Templates.DevStatus.DetailDialog.reviewersList = function(opt_data, opt_ignored) {
  var output = '<div class="reviewer-container">';
  var showThreshold__soy64 = opt_data.countThreshold + 1;
  var indexLimit65 = Math.min(opt_data.countThreshold, opt_data.reviewers.length);
  for (var index65 = 0; index65 < indexLimit65; index65++) {
    output += JIRA.Templates.DevStatus.DetailDialog.vcsUser(opt_data.reviewers[index65]);
  }
  output += ((opt_data.reviewers.length == showThreshold__soy64) ? JIRA.Templates.DevStatus.DetailDialog.vcsUser(opt_data.reviewers[opt_data.countThreshold]) : (opt_data.reviewers.length > showThreshold__soy64) ? '<span class="aui-badge extrareviewers-tooltip reviewers-link" data-reviewers="' + soy.$$escapeHtml(opt_data.extraReviewers) + '">' + soy.$$escapeHtml(opt_data.reviewers.length - opt_data.countThreshold) + '</span>' : '') + '</div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.reviewersList.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.reviewersList';
}


JIRA.Templates.DevStatus.DetailDialog.branch = function(opt_data, opt_ignored) {
  return '<div class="detail-branches-container"><div class="devstatus-detail-table branches-table"><table class="aui"><thead><tr><th class="repository">' + soy.$$escapeHtml("Repository") + '</th><th class="branch">' + soy.$$escapeHtml("Branch") + '</th>' + ((opt_data.features.lastCommitId) ? '<th class="changeset cell-type-collapsed">' + soy.$$escapeHtml("Last commit") + '</th>' : '') + ((opt_data.features.lastCommitTimestamp) ? '<th class="last-updated cell-type-collapsed">' + soy.$$escapeHtml("Last modified") + '</th>' : '') + ((opt_data.features.pullRequests) ? '<th class="pullrequest">' + soy.$$escapeHtml("Pull request") + '</th>' : '') + ((opt_data.features.reviews) ? '<th class="review">' + soy.$$escapeHtml("Review") + '</th>' : '') + ((opt_data.features.pullRequests || opt_data.features.reviews) ? '<th class="action">' + soy.$$escapeHtml("Action") + '</th>' : '') + '</tr></thead><tbody>' + JIRA.Templates.DevStatus.DetailDialog.branchEntry(opt_data) + '</tbody></table></div></div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.branch.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.branch';
}


JIRA.Templates.DevStatus.DetailDialog.branchEntry = function(opt_data, opt_ignored) {
  var output = '';
  var branchList113 = opt_data.branches;
  var branchListLen113 = branchList113.length;
  for (var branchIndex113 = 0; branchIndex113 < branchListLen113; branchIndex113++) {
    var branchData113 = branchList113[branchIndex113];
    output += '<tr class="branch-row"><td class="repository">' + JIRA.Templates.DevStatus.DetailDialog.repositoryHeader(soy.$$augmentMap(opt_data, {repository: branchData113.repository, showTooltip: true})) + '</td><td class="branch">' + JIRA.Templates.DevStatus.DetailDialog.branchLozenge(branchData113) + '</td>' + ((opt_data.features.lastCommitId) ? '<td class="changeset cell-type-collapsed">' + ((branchData113.lastCommit && branchData113.lastCommit.displayId) ? (branchData113.lastCommit.url) ? '<a class="changeset-link changesetid" href="' + soy.$$escapeHtml(branchData113.lastCommit.url) + '">' + soy.$$escapeHtml(branchData113.lastCommit.displayId) + '</a>' : '<span class="changeset-link changesetid">' + soy.$$escapeHtml(branchData113.lastCommit.displayId) + '</span>' : '') + '</td>' : '') + ((opt_data.features.lastCommitTimestamp) ? '<td class="last-updated cell-type-collapsed">' + ((branchData113.lastCommit && branchData113.lastCommit.authorTimestamp) ? JIRA.Templates.DevStatus.DetailDialog.timestamp({timestamp: branchData113.lastCommit.authorTimestamp}) : '') + '</td>' : '') + ((opt_data.features.pullRequests) ? '<td class="pullrequest">' + JIRA.Templates.DevStatus.DetailDialog.pullRequestStatusForBranch(branchData113.pullRequestState) + '</td>' : '') + ((opt_data.features.reviews) ? '<td class="review">' + JIRA.Templates.DevStatus.DetailDialog.reviewStatusForBranch({reviewData: branchData113.reviews}) + '</td>' : '') + ((opt_data.features.pullRequests || opt_data.features.reviews) ? '<td class="action">' + ((branchData113.createPullRequestUrl && branchData113.createPullRequestUrl.length > 0) ? '<a class="create-pullrequest-link" href="' + soy.$$escapeHtml(branchData113.createPullRequestUrl) + '">' + soy.$$escapeHtml("Create pull request") + '</a>' : '') + ((branchData113.createReviewUrl && branchData113.createReviewUrl.length > 0) ? '<a class="create-review-link" href="' + soy.$$escapeHtml(branchData113.createReviewUrl) + '">' + soy.$$escapeHtml("Create review") + '</a>' : '') + '</td>' : '') + '</tr>';
  }
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.branchEntry.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.branchEntry';
}


JIRA.Templates.DevStatus.DetailDialog.pullRequestStatusForBranch = function(opt_data, opt_ignored) {
  return '' + ((opt_data.total > 0) ? '<a href="#" class="pullrequest-tooltip pullrequest-link pullrequest-status" data-detail="' + soy.$$escapeHtml(opt_data.data) + '">' + JIRA.Templates.DevStatus.DetailDialog.pullRequestState({status: opt_data.status, isSubtle: true}) + '</a>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.pullRequestStatusForBranch.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.pullRequestStatusForBranch';
}


JIRA.Templates.DevStatus.DetailDialog.reviewStatusForBranch = function(opt_data, opt_ignored) {
  return '' + ((opt_data.reviewData && opt_data.reviewData.totalCount > 0) ? '<a href="#" class="review-tooltip review-link review-status" data-detail="' + soy.$$escapeHtml(opt_data.reviewData.json) + '">' + JIRA.Templates.FusionWidget.Common.reviewsStateViewIssue({state: opt_data.reviewData.reviews[0].state}) + '</a>' : '');
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.reviewStatusForBranch.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.reviewStatusForBranch';
}


JIRA.Templates.DevStatus.DetailDialog.pullRequestSingle = function(opt_data, opt_ignored) {
  return '<a class="pullrequest-link' + ((opt_data.extraClasses) ? ' ' + soy.$$escapeHtml(opt_data.extraClasses) : '') + '" href="' + soy.$$escapeHtml(opt_data.url) + '" ><span>' + soy.$$escapeHtml(opt_data.id) + ' ' + soy.$$escapeHtml(opt_data.name) + '</span></a>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.pullRequestSingle.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.pullRequestSingle';
}


JIRA.Templates.DevStatus.DetailDialog.extraReviewersTooltip = function(opt_data, opt_ignored) {
  var output = '<div class="reviewer"><div class="reviewer-container"><table class="aui"><tbody>';
  var reviewerList211 = opt_data.reviewers;
  var reviewerListLen211 = reviewerList211.length;
  for (var reviewerIndex211 = 0; reviewerIndex211 < reviewerListLen211; reviewerIndex211++) {
    var reviewerData211 = reviewerList211[reviewerIndex211];
    output += '<tr><td class="reviewer-avatar">' + JIRA.Templates.DevStatus.DetailDialog.vcsUser(reviewerData211) + '</td><td class="reviewer-name"><span title="' + soy.$$escapeHtml(reviewerData211.name) + '">' + soy.$$escapeHtml(reviewerData211.name) + '</span></td></tr>';
  }
  output += '</tbody></table></div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.extraReviewersTooltip.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.extraReviewersTooltip';
}


JIRA.Templates.DevStatus.DetailDialog.pullRequestToolTip = function(opt_data, opt_ignored) {
  var output = '<table class="aui"><tbody>';
  var pullRequestList223 = opt_data.pullRequests;
  var pullRequestListLen223 = pullRequestList223.length;
  for (var pullRequestIndex223 = 0; pullRequestIndex223 < pullRequestListLen223; pullRequestIndex223++) {
    var pullRequestData223 = pullRequestList223[pullRequestIndex223];
    output += '<tr><td class="pullrequest-name">' + JIRA.Templates.DevStatus.DetailDialog.pullRequestSingle(pullRequestData223) + '</td><td class="lozenge">' + JIRA.Templates.DevStatus.DetailDialog.pullRequestState({status: pullRequestData223.status, isSubtle: false}) + '</td></tr>';
  }
  output += '</tbody></table>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.pullRequestToolTip.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.pullRequestToolTip';
}


JIRA.Templates.DevStatus.DetailDialog.pullRequestState = function(opt_data, opt_ignored) {
  return '' + JIRA.Templates.FusionWidget.Common.reviewsState({isSubtle: opt_data.isSubtle, state: opt_data.status, stateClasses: {OPEN: 'aui-lozenge-complete', MERGED: 'aui-lozenge-success', DECLINED: 'aui-lozenge-error'}, stateText: {OPEN: "OPEN", MERGED: "MERGED", DECLINED: "DECLINED"}, classes: 'pullrequest-state'});
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.pullRequestState.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.pullRequestState';
}


JIRA.Templates.DevStatus.DetailDialog.branchLozenge = function(opt_data, opt_ignored) {
  return '<div class="branch-name"><span class="aui-icon aui-icon-small aui-iconfont-devtools-branch-small"></span>' + ((opt_data.url) ? '<a class="branch-link' + ((opt_data.extraClasses) ? ' ' + soy.$$escapeHtml(opt_data.extraClasses) : '') + '" href="' + soy.$$escapeHtml(opt_data.url) + '" title="' + soy.$$escapeHtml(opt_data.name) + '">' + soy.$$escapeHtml(opt_data.name) + '</a>' : '<span class="branch-link' + ((opt_data.extraClasses) ? ' ' + soy.$$escapeHtml(opt_data.extraClasses) : '') + '" title="' + soy.$$escapeHtml(opt_data.name) + '">' + soy.$$escapeHtml(opt_data.name) + '</span>') + '</div>';
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.branchLozenge.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.branchLozenge';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'templates/viewissue/devstatus-detail-dialog-review.soy' */
// This file was automatically generated from devstatus-detail-dialog-review.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Templates.DevStatus.DetailDialog.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Templates == 'undefined') { JIRA.Templates = {}; }
if (typeof JIRA.Templates.DevStatus == 'undefined') { JIRA.Templates.DevStatus = {}; }
if (typeof JIRA.Templates.DevStatus.DetailDialog == 'undefined') { JIRA.Templates.DevStatus.DetailDialog = {}; }


JIRA.Templates.DevStatus.DetailDialog.review = function(opt_data, opt_ignored) {
  var output = '<div class="devstatus-detail-table detail-reviews-container"><div class="devstatus-detail-table reviews-table"><table class="aui"><thead><tr><th class="review cell-type-collapsed">' + soy.$$escapeHtml("ID") + '</th><th class="title">' + soy.$$escapeHtml("Title") + '</th><th class="state cell-type-collapsed">' + soy.$$escapeHtml("Status") + '</th><th class="author cell-type-collapsed">' + soy.$$escapeHtml("Author") + '</th><th class="reviewer cell-type-collapsed">' + soy.$$escapeHtml("Reviewers") + '</th><th class="comment cell-type-collapsed"></th><th class="timestamp">' + soy.$$escapeHtml("Date") + '</th></tr></thead><tbody>';
  var reviewList16 = opt_data.reviews;
  var reviewListLen16 = reviewList16.length;
  for (var reviewIndex16 = 0; reviewIndex16 < reviewListLen16; reviewIndex16++) {
    var reviewData16 = reviewList16[reviewIndex16];
    output += '<tr data-id="' + soy.$$escapeHtml(reviewData16.id) + '"><td class="review"><a href="' + soy.$$escapeHtml(reviewData16.url) + '" class="review-link">' + soy.$$escapeHtml(reviewData16.id) + '</a></td><td class="title"><span class="ellipsis" title="' + soy.$$escapeHtml(reviewData16.title) + '">' + soy.$$escapeHtml(reviewData16.title) + '</span></td><td class="state">' + JIRA.Templates.FusionWidget.Common.reviewsStateViewIssue({state: reviewData16.state}) + '</td><td class="author">' + ((reviewData16.author) ? JIRA.Templates.DevStatus.DetailDialog.vcsUser(reviewData16.author) : '') + '</td><td class="reviewer">' + JIRA.Templates.DevStatus.DetailDialog.reviewersList(soy.$$augmentMap(reviewData16, {countThreshold: opt_data.reviewersThreshold, extraReviewers: reviewData16.extraReviewers})) + '</td><td class="comment cell-type-collapsed">' + JIRA.Templates.DevStatus.DetailDialog.commentCount({pullRequest: {commentCount: reviewData16.commentCount, url: reviewData16.url}}) + '</td><td class="timestamp">' + JIRA.Templates.DevStatus.Review.reviewDate(soy.$$augmentMap(reviewData16, {lastUpdated: reviewData16.lastModified, showUpdatedText: false})) + '</td></tr>';
  }
  output += '</tbody></table></div></div>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Templates.DevStatus.DetailDialog.review.soyTemplateName = 'JIRA.Templates.DevStatus.DetailDialog.review';
}
;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/util/Helpers.js' */
define("jira-development-status/util/helpers",["underscore"],function(a){var c=function(){if(soydata.VERY_UNSAFE){return soydata.VERY_UNSAFE.ordainSanitizedHtml}else{return function(d){return new soydata.SanitizedHtml(d)}}};return{getContextPath:AJS.contextPath,copyAndMarkStringPropertiesAsSanitised:function b(f){var e=c();var d=Array.isArray(f)?[]:{};a.each(a.keys(f),function(g){var h=f[g];if(h){if(typeof h==="string"){d[g]=e(h)}else{if(typeof h==="object"){if(a.keys(h).length>0){d[g]=b(h)}}else{d[g]=h}}}});return d}}});;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/CreateReviewFormDialog.js' */
define("jira/devstatus/create-review-form-dialog",["backbone","jquery","require","underscore","jira/dialog/form-dialog","jira-development-status/util/WRM","jira/dev-status/util/url","jira-development-status/util/navigate"],function(h,f,b,a,c,d,e,g){return h.View.extend({initialize:function(i){this.linkSelector=i.linkSelector;this.applicationType=i.applicationType;this.instances=i.instances;this.issueId=i.issueId;this.dialog.instance=this},renderSuccess:function(){f(".create-review-instance a").attr("href",e.getCreateReviewDetailUrl(this.applicationType))},_processTargets:function(j){var k=this,i=a.map(j,function(m){var l=a.find(k.instances,function(n){return n.applicationLinkId===m.applicationLinkId});if(!l){return null}return a.extend({},m,l)});return a.sortBy(a.filter(i,a.identity),"name")},dialog:new c({id:"devstatus-cta-create-review-dialog",trigger:".create-review-instance a",width:560,content:function(k){var i=this.instance,j=this;d.requireDetailDialogResources(function(){var l=b("jira/devstatus/instance-picker-view");j.pickerView=new l({el:j.$popup,activeTrigger:j.$activeTrigger,cta:"devstatus.cta.createreview",issueId:i.issueId,processTargets:function(m){return j.instance._processTargets.call(j.instance,m)},uniqueResultAction:function(m){JIRA.DevStatus.CommitsAnalytics.fireDetailCreateReviewClicked(i.applicationType,true);g.navigate(m.url)}});j.pickerView.render().always(function(m){k(m);f(j.$popup).find(".primary.target").eq(0).focus();f(".target").click(function(n){JIRA.DevStatus.CommitsAnalytics.fireDetailCreateReviewClicked(i.applicationType,true)})})})},autoClose:true})})});Backbone.define("JIRA.DevStatus.CreateReviewFormDialog",require("jira/devstatus/create-review-form-dialog"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/BaseDetailDialogView.js' */
define("jira/devstatus/base-detail-dialog-view",["backbone","jquery","underscore"],function(c,b,a){return c.View.extend({frameEvents:{"click .menu-item":"_doTabClick"},frameTemplate:JIRA.Templates.DevStatus.DetailDialogFrame.frame,oauthStatusTemplate:JIRA.Templates.DevStatus.DetailDialog.oauthStatus,authenticationTemplate:JIRA.Templates.DevStatus.DetailDialog.authenticationScreen,connectionProblemTemplate:JIRA.Templates.DevStatus.DetailDialog.connectionProblemScreen,connectionProblemWarningTemplate:JIRA.Templates.DevStatus.connectionProblemAsWarning,noPermissionToViewAllTemplate:JIRA.Templates.DevStatus.DetailDialog.noPermissionToViewAll,oauthDanceFailedTemplate:JIRA.Templates.DevStatus.DetailDialog.oauthDanceFailed,initialize:function(d){this.options=a.defaults({},d,{width:560,model:new JIRA.DevStatus.BaseDetailDialogModel(d)});this.model=this.options.model;this._initFetchHandlers();this._initFormDialog()},renderSuccess:function(e,d){return this},shouldRefreshOnTabSwitch:function(d){return false},getTitle:function(e,d){console.warn("Unimplemented getTitle() function",this);return d},getOAuthMessageInFooter:function(d){return AJS.format("You might be able to see more information by authenticating with the following {0,choice,1#application|1\u003capplications}:",d.length)},getOAuthMessageInCanvas:function(){return "Authenticate to see related development information"},getConnectionMessageInCanvas:function(){return "Unable to retrieve development information"},getNoPermissionToViewAllMessageInCanvas:function(){return "Unable to retrieve development information"},getContactAdmistratorsOrLoginMessageInCanvas:function(){if(JIRA.Users.LoggedInUser.isAnonymous()){return "You might be able to view more by authenticating with JIRA."}else{return "Please contact your administrator."}},hasData:function(d){return d.length>0},show:function(){this.dialog.show()},hide:function(){this.dialog.hide()},_getPane:function(d){return d?this.$el.find("#tab-content-"+d.replace(/(:|\.|\[|\])/g,"\\$1")):b()},getContentContainer:function(d){return this._getPane(d||this._getActiveApplicationType()).find(".detail-content-container")},_doTabClick:function(f){f.preventDefault();var d=this._getActiveApplicationType();this.model.switchTab(d,this.shouldRefreshOnTabSwitch(d));this.analytics&&this.analytics.fireDetailTabClicked(d)},_redirectToLoginIf401:function(d){if(d&&d.status===401){JIRA.DevStatus.Navigate.redirectToLogin();return true}return false},_initFetchHandlers:function(){this.model.on("fetchRequested",this._showLoadingIndicator,this);this.model.on("fetchSucceeded",this._handleFetchSucceeded,this);this.model.on("fetchFailed",this._handleFetchFailed,this)},_handleFetchSucceeded:function(f,d){this._hideLoadingIndicator(f);var e=d.detail&&this.hasData(d.detail);if(e){this.renderSuccess(f,d.detail)}this._renderError(f,d.errors,e);this._postRender()},_handleFetchFailed:function(e,d){this._hideLoadingIndicator(e);if(!this._redirectToLoginIf401(d)){this._renderError(e,[],false,true)}},_initAuthenticationCallbacks:function(){this._patchAJSIconsForAppLinks();var d=this;var i=function(k,j){d.model.oauthStatusChanged(j.appType);d.model.fetchAuthenticationStatuses();k.preventDefault()};var f=function(j){var k=null;if(j.id&&j.appUri&&j.appName&&j.appType){k={applicationLinkId:j.id,baseUrl:j.appUri,name:j.appName,type:j.appType}}return k};var e=function(j,o){var p=[f(j)];var m=require("jira-development-status/util/helpers");var l=m.copyAndMarkStringPropertiesAsSanitised(o);var k=function(){if(JIRA.isAdmin()){d._renderConnectionError(d.model._getCurrentApplicationType(),p,{message:l.adminError,details:l.adminErrorDetails})}else{d._renderConnectionError(d.model._getCurrentApplicationType(),p)}};var n=function(){d._renderAuthenticationError(d.model._getCurrentApplicationType(),p,[],l.userError)};if(l.adminError){k()}else{if(l.userError){n()}}};var h=function(l,j,k){if(k){e(j,k)}b.ajax(AJS.contextPath()+"/rest/auth/1/session").promise().fail(function(m){d._redirectToLoginIf401(m)})};var g=b(document);g.bind("applinks.auth.approved",i);g.bind("applinks.auth.denied",h);b(this.dialog).bind("Dialog.beforeHide",function(){g.unbind("applinks.auth.approved",i);g.unbind("applinks.auth.denied",h);d.model.off(null,null,d);d.instanceListPopup&&d.instanceListPopup.remove()});b('<div class="applinks-auth-confirmation-container hidden"></div>').appendTo(this.$el)},_initFetchAuthenticationHandlers:function(){this.model.on("fetchAuthRequested",this._showLoadingIndicator,this);this.model.on("fetchAuthSucceeded",this._handleAuthSucceeded,this);this.model.on("fetchAuthFailed",this._handleAuthFailed,this)},_handleAuthSucceeded:function(e){var d=this;var g=a.filter(e,function(h){return h.configured&&!h.authenticated&&h.source&&h.source.applicationLinkId});var f=this._getOAuthStatusDiv();if(g.length>0&&!JIRA.Users.LoggedInUser.isAnonymous()){f.html(this.oauthStatusTemplate({message:this.getOAuthMessageInFooter(g)}));this._renderUnauthInstancesInFooter(g);f.show()}else{f.hide()}},_handleAuthFailed:function(d){this._redirectToLoginIf401(d);this._getOAuthStatusDiv().hide()},_renderUnauthInstancesInFooter:function(f){var e=this._getOAuthStatusDiv();var g=a.map(a.pluck(f,"source"),this._createOAuthInstanceDiv);if(g.length>0){e.append(g[0]);if(g.length>1){e.append(", ");e.append(g[1]);if(g.length>2){e.append(" ");var h=b('<span class="more-instances"><a href="#">'+"... more"+"</a></span>");e.append(h);var d=b('<ul class="instance-list"></ul>');a.each(g.slice(2),function(i){d.append(b('<li class="instance-in-popup"></li>').append(i))});AJS.InlineDialog(h,"instance-list-popup",function(j,i,k){j.html(d);k();return false},{width:150,offsetX:-100,onTop:true})}}}},_createOAuthInstanceDiv:function(d){var e=ApplinksUtils.createAuthRequestInline(null,{id:d.applicationLinkId,authUri:AJS.contextPath()+"/plugins/servlet/applinks/oauth/login-dance/authorize?applicationLinkID="+encodeURIComponent(d.applicationLinkId),appUri:d.baseUrl,appName:d.name,appType:d.type});return b('<span class="instance"></span>').append(e.find("a.applink-authenticate").text(d.name))},_patchAJSIconsForAppLinks:function(){AJS.icons=AJS.icons||{};AJS.icons.addIcon=AJS.icons.addIcon||{};AJS.icons.addIcon.init=AJS.icons.addIcon.init||function(){}},_getOAuthStatusDiv:function(){var d=this.$el.find(".buttons-container .oauth-status");if(d.length){return d}else{return b('<div class="oauth-status" />').appendTo(this.$el.find(".buttons-container.form-footer"))}},_renderError:function(i,j,g,f){var d=a.groupBy(j,function(k){var l=k.error;if(l==="unauthorized"||l==="incapable"){return l}else{return"others"}});var e=a.pluck(d.unauthorized,"instance");var h=a.pluck(d.others,"instance");if(e.length>0){this.model.fetchAuthenticationStatuses()}if(g){if(h.length>0){this._renderConnectionErrorBeforeData(i,h)}}else{if(e.length>0){this._renderAuthenticationError(i,e,h)}else{if(f||h.length>0){this._renderConnectionError(i,h)}else{this._renderNoPermissionToViewAllWarning(i)}}}},_renderConnectionErrorBeforeData:function(e,d){this.getContentContainer(e).prepend(this.connectionProblemWarningTemplate({instances:d,showContactAdminForm:this.options.showContactAdminForm}))},_renderConnectionError:function(f,e,d){this.getContentContainer(f).html(this.connectionProblemTemplate({instances:e,adminError:d,showContactAdminForm:this.options.showContactAdminForm,title:this.getConnectionMessageInCanvas()}))},renderNoPermissionToViewAllWarningAtBottom:function(f,g){var d=this.model.get("tabs")[f]||{};var e=this.model.get("contentMap")[f]||{};if(g<d.count){if((e.errors||[]).length===0||JIRA.Users.LoggedInUser.isAnonymous()){this.getContentContainer(f).append(this._getNoPermissionToViewAllHtml())}}},_getNoPermissionToViewAllHtml:function(){return this.noPermissionToViewAllTemplate({message:this.getNoPermissionToViewAllMessageInCanvas(),secondaryMessage:this.getContactAdmistratorsOrLoginMessageInCanvas()})},_renderNoPermissionToViewAllWarning:function(d){this.getContentContainer(d).html(this._getNoPermissionToViewAllHtml())},_renderAuthenticationError:function(j,g,i,f){var d=this.getContentContainer(j);d.html(this.authenticationTemplate({unauthInstances:g,title:this.getOAuthMessageInCanvas(),otherInstances:i,showContactAdminForm:this.options.showContactAdminForm,userError:f}));var h=a.map(g,this._createOAuthInstanceDiv);var e=d.find(".instances");a.each(h,function(l,k){if(k!==0){e.append(", ")}e.append(l)})},_initFormDialog:function(){var d=this;this.dialog=new JIRA.FormDialog({id:this.options.id,width:this.options.width,content:function(e){d.setElement(this.$popup);d.delegateEvents(a.extend({},d.frameEvents,d.events));d._renderFrame();d._initAuthenticationCallbacks();d._initFetchAuthenticationHandlers();d.model.fetchAuthenticationStatuses();d.model.switchTab(d._getActiveApplicationType());e()},autoClose:true})},_postRender:function(){this.$el.find(".extra-content-in-title").tooltip();this.dialog._positionInCenter();this.$el.find(".active-pane a:eq(0)").focus()},_getActiveApplicationType:function(){return this.$el.find(".menu-item.active-tab").data("applicationType")},_showLoadingIndicator:function(f){var d=this._getPane(f);d._removeClass("ready");d.addClass("loading");var e=d.find(".status-loading");e.spin("large");e.show()},_hideLoadingIndicator:function(f){var d=this._getPane(f);d.addClass("ready");var e=d.find(".status-loading");if(e){d.removeClass("loading");e.hide();e.spinStop()}},_renderFrame:function(){this.$el.html(this.frameTemplate({title:this.getTitle(this.options.count,this.options.issueKey),tabs:this._convertTabsForSoy(),initialTab:this.options.initialTab}));if(this.options.height){this.$el.find(".form-body").css("min-height",this.options.height)}},_convertTabsForSoy:function(){return a.chain(this.model.get("tabs")).map(function(e,d){return a.extend({type:d},e)}).sortBy(function(d){return d.type}).value()},_createReviewersInlineDialog:function(){this.reviewerInlineDialogView=new JIRA.DevStatus.ReviewerInlineDialogView({el:this.$el.find(".extrareviewers-tooltip")});return this.reviewerInlineDialogView},_sortReviewsByStatus:function(d){var e=["REVIEW","APPROVAL","SUMMARIZE","REJECTED","CLOSED"];return a.chain(d).filter(function(f){return a.contains(e,f.state)}).sortBy(function(f){return a.indexOf(e,f.state)}).value()},_setupReviewsPopup:function(i,f,d,g){i.preventDefault();var h=b(i.currentTarget);if(!h.data("inline-dialog-inited")){var j="commit-reviews-popup-"+(this._tooltipSeq++);this.activeReviewsToolTip=AJS.InlineDialog(h,j,function(l,e,m){var k=f(b(e));d&&d();l.html(JIRA.Templates.DevStatus.DetailDialog.reviewsInlineDialog({reviewData:k}));if(g){l.find("a").click(g)}m()},{cacheContent:false,hideDelay:200,showDelay:50,onHover:true,width:false});h.data("inline-dialog-inited",true).mouseenter()}},_removeInlineDialog:function(d){if(this[d]){this[d].hide();this[d].remove();this[d]=undefined}}})});Backbone.define("JIRA.DevStatus.BaseDetailDialogView",require("jira/devstatus/base-detail-dialog-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/BaseDetailDialogModel.js' */
define("jira/devstatus/base-detail-dialog-model",["backbone","jquery","underscore"],function(c,b,a){return c.Model.extend({TAB_PREFIX:"#tab-menu-",PANE_PREFIX:"#tab-content-",properties:["tabs","contentMap","oauthStatuses","selectedTab","selectedPane"],namedEvents:["fetchRequested","fetchFailed","fetchSucceeded","fetchAuthRequested","fetchAuthFailed","fetchAuthSucceeded"],initialize:function(d){this.issueKey=d.issueKey;this.issueId=d.issueId;this.type=d.dataType;this.set("contentMap",{});this.set("tabs",d.tabs)},switchTab:function(e,d){this.set("selectedTab",this.TAB_PREFIX+e);this.set("selectedPane",this.PANE_PREFIX+e);if(this.get("contentMap")[e]==null||d){this._fetchContents(e)}},_fetchContents:function(d){this.trigger("fetchRequested",d);this._handleFetch(d,b.ajax({url:AJS.contextPath()+"/rest/dev-status/1.0/issue/detail",data:{issueId:this.issueId,applicationType:d,dataType:this.type}}).promise())},_handleFetch:function(f,e){var d=this;e.done(function(g){d._fireSuccessResult(f,g)}).fail(function(h,g){d._fireFailResult(f,h)})},_fireSuccessResult:function(e,d){this._updateContents(e,d);this.trigger("fetchSucceeded",e,d)},_fireFailResult:function(e,d){this._updateContents(e);this.trigger("fetchFailed",e,d)},_updateContents:function(e,d){this.get("contentMap")[e]=d},fetchAuthenticationStatuses:function(){var e=a.keys(this.get("tabs")||{});if(!a.isEmpty(e)){var d=this;b.ajax({url:AJS.contextPath()+"/rest/dev-status/1.0/provider/auth-status",data:{applicationType:e}}).promise().done(function(f){if(f&&f.data){d._updateOAuthStatuses(f.data);d.trigger("fetchAuthSucceeded",f.data)}else{d._updateOAuthStatuses();d.trigger("fetchAuthFailed",null,f)}}).fail(function(g,f){d._updateOAuthStatuses();d.trigger("fetchAuthFailed",g)})}},oauthStatusChanged:function(e){if(a.has(this.get("tabs"),e)){var d=this._getCurrentApplicationType();if(d===e){this._fetchContents(d)}else{this.get("contentMap")[e]=null}}},_getCurrentApplicationType:function(){var d=this.get("selectedTab");if(d){return d.slice(this.TAB_PREFIX.length)}return null},_updateOAuthStatuses:function(d){this.set("oauthStatuses",d)}})});Backbone.define("JIRA.DevStatus.BaseDetailDialogModel",require("jira/devstatus/base-detail-dialog-model"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/ReviewerInlineDialogView.js' */
define("jira/devstatus/reviewer-inline-dialog-view",["jquery","jira/devstatus/base-detail-dialog-view"],function(b,a){return a.extend({extraReviewersToolTipTemplate:JIRA.Templates.DevStatus.DetailDialog.extraReviewersTooltip,events:{mouseenter:"_onHoverExtraReviewersToolTip",click:"_onClickExtraReviewersToolTip"},_tooltipSeq:1,_onHoverExtraReviewersToolTip:function(f){f.preventDefault();var c=this;var d=b(f.currentTarget);if(!d.data("inline-dialog-inited")){var g="extrareviewers-tooltip-"+(this._tooltipSeq++);this.activeExtraReviewersToolTip=AJS.InlineDialog(d,g,function(i,h,j){var e=b(h);i.html(c.extraReviewersToolTipTemplate({reviewers:e.data("reviewers")}));c.activeExtraReviewersToolTip.$content=i;j()},{cacheContent:false,hideDelay:200,onHover:true,width:false});d.data("inline-dialog-inited",true).mouseenter()}},_onClickExtraReviewersToolTip:function(c){if(this.activeExtraReviewersToolTip){c.stopPropagation()}}})});Backbone.define("JIRA.DevStatus.ReviewerInlineDialogView",require("jira/devstatus/reviewer-inline-dialog-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/build/DetailDialogBuildView.js' */
define("jira/devstatus/detail-dialog-build-view",["underscore","jira/devstatus/base-detail-dialog-view"],function(b,a){return a.extend({template:JIRA.Templates.DevStatus.DetailDialog.build,events:{"click a.project-link":"_onClickProjectLink","click a.plan-link":"_onClickPlanLink","click a.build-link":"_onClickBuildLink"},initialize:function(c){this.analytics=JIRA.DevStatus.BuildsAnalytics;a.prototype.initialize.call(this,b.extend({type:"build",width:1000,height:400},c))},renderSuccess:function(f,c){var e=b.reduce(c,function(g,h){return g.concat(h.projects||[])},[]);var d=this.getContentContainer(f);d.html(this.template({applicationType:f,projects:this.sortProjectsAndPlans(e),hasArtifacts:this.hasArtifacts(e)}));this.renderNoPermissionToViewAllWarningAtBottom(f,this.getBuildCount(e));JIRA.DevStatus.Date.addTooltip(d);return this},getTitle:function(d,c){return AJS.format("{1}: {0} {0,choice,1#build|1\u003cbuilds}",d,c)},getOAuthMessageInFooter:function(c){return AJS.format("You might be able to see more builds by authenticating with the following {0,choice,1#application|1\u003capplications}:",c.length)},getOAuthMessageInCanvas:function(){return "Authenticate to see related builds"},getConnectionMessageInCanvas:function(){return "Unable to retrieve build information"},getNoPermissionToViewAllMessageInCanvas:function(){return "You don\'t have access to view all related builds."},hasData:function(c){return b.reduce(c,function(d,e){return d.concat(e.projects||[])},[]).length>0},sortProjectsAndPlans:function(c){c=b.sortBy(c,function(d){return b.last(b.sortBy(d.plans,function(e){return e.build.finishedDate})).build.finishedDate}).reverse();b.each(c,function(d){d.plans=b.sortBy(d.plans,function(e){return e.build.finishedDate}).reverse()});return c},hasArtifacts:function(c){return b.any(c,function(d){return b.any(d.plans,function(e){return e.build&&e.build.artifacts&&e.build.artifacts.length})})},getBuildCount:function(c){return b.union.apply(null,b.map(c,function(d){return b.pluck(d.plans,"key")})).length},_onClickProjectLink:function(){JIRA.DevStatus.BuildsAnalytics.fireDetailProjectClicked()},_onClickPlanLink:function(){JIRA.DevStatus.BuildsAnalytics.fireDetailPlanClicked()},_onClickBuildLink:function(){JIRA.DevStatus.BuildsAnalytics.fireDetailBuildClicked()}})});Backbone.define("JIRA.DevStatus.DetailDialogBuildView",require("jira/devstatus/detail-dialog-build-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/deployment/DetailDialogDeploymentView.js' */
define("jira/devstatus/detail-dialog-deployment-view",["underscore","jira/devstatus/base-detail-dialog-view"],function(b,a){return a.extend({template:JIRA.Templates.DevStatus.DetailDialog.Deployment.deployment,events:{"click a.project-link":"_onClickProjectLink","click a.environment-link":"_onClickEnvironmentLink","click a.release-link":"_onClickReleaseLink"},initialize:function(c){this.analytics=JIRA.DevStatus.DeploymentsAnalytics;a.prototype.initialize.call(this,b.extend({type:"deployment",width:1000,height:400},c))},renderSuccess:function(f,c){var e=b.reduce(c,function(g,h){return g.concat(h.deploymentProjects||[])},[]);var d=this.getContentContainer(f);d.html(this.template({applicationType:f,deploymentProjects:this.sortProjects(e)}));this.renderNoPermissionToViewAllWarningAtBottom(f,this.getEnvironmentCount(e));JIRA.DevStatus.Date.addTooltip(d);return this},getTitle:function(d,c){return AJS.format("{1}: {0} {0,choice,1#deployment|1\u003cdeployments}",d,c)},getOAuthMessageInFooter:function(c){return AJS.format("You might be able to see more deployments by authenticating with the following {0,choice,1#application|1\u003capplications}:",c.length)},getOAuthMessageInCanvas:function(){return "Authenticate to see related deployments"},getConnectionMessageInCanvas:function(){return "Unable to retrieve deployment information"},getNoPermissionToViewAllMessageInCanvas:function(){return "You don\'t have access to view all related deployments."},hasData:function(c){return b.reduce(c,function(d,e){return d.concat(e.deploymentProjects||[])},[]).length>0},sortProjects:function(c){return b.sortBy(c,function(d){return b.last(b.sortBy(d.environments,function(e){return new Date(e.lastDeployed||0).getTime()})).lastDeployed}).reverse()},getEnvironmentCount:function(c){return b.union.apply(null,b.map(c,function(d){return b.pluck(d.environments,"environmentId")})).length},_onClickProjectLink:function(){JIRA.DevStatus.DeploymentsAnalytics.fireDetailProjectClicked()},_onClickEnvironmentLink:function(){JIRA.DevStatus.DeploymentsAnalytics.fireDetailEnvironmentClicked()},_onClickReleaseLink:function(){JIRA.DevStatus.DeploymentsAnalytics.fireDetailReleaseClicked()}})});Backbone.define("JIRA.DevStatus.DetailDialogDeploymentView",require("jira/devstatus/detail-dialog-deployment-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/DetailDialogCommitView.js' */
define("jira/devstatus/detail-dialog-commit-view",["jquery","underscore","jira/devstatus/base-detail-dialog-view","jira/util/data/meta"],function(d,b,a,c){return a.extend({template:JIRA.Templates.DevStatus.DetailDialog.commit,events:{"click a.repository-link":"_onClickRepositoryLink","click a.changesetid":"_onClickChangesetId","click .filecount a":"_onClickFiles","click .file-expand a":"_onClickExpand","click .create-review-commit a":"_onClickCreateReview","click .filename a":"_onClickFile","mouseenter .reviews-link":"_onHoverReviewsToolTip",click:"_onClickReviewsToolTip"},initialize:function(e){this.analytics=JIRA.DevStatus.CommitsAnalytics;this.issueId=e.issueId;var g=c.get("fusion-open-detail-dialog");var f;if(JIRA.DevStatus.URL.isCreateReviewDetailDialogLink(g)){f=JIRA.DevStatus.URL.getCreateReviewDetailDialogApplicationType(g)}a.prototype.initialize.call(this,b.extend({type:"commit",width:1000,height:400,initialTab:f},e))},concatResults:function(e){return b.reduce(e,function(f,h){var g=h.repositories||[];b.each(g,function(i){i.showInstance=h._instance&&!h._instance.singleInstance;i.instance=h._instance});return f.concat(g)},[])},_clipEllipsis:function(){function e(f){return f.outerWidth()}this.$el.find(".detail-content-container .file .ellipsis").each(function(f,k){var j=d(k);var g=e(j);if(g==0){return}var h=j.find("a");if(e(h)>g){var l=h.text();while(e(h)>g){l=l.slice(1);h.text("\u2026"+l)}}})},renderSuccess:function(i,e){var g=this.concatResults(e);var f=this.getContentContainer(i);this.transformedRepositories=this.transformRepositories(g);var h=this.setupCreateReviewDialog(this.transformedRepositories);f.html(this.template({applicationType:i,repositories:this.transformedRepositories,canCreateReview:h}));this.renderNoPermissionToViewAllWarningAtBottom(i,this.getUniqueCommitCount(g));JIRA.DevStatus.Date.addTooltip(f);this.setupBranchesTooltip();this.createReviewDialog&&this.createReviewDialog.renderSuccess();return this},setupCreateReviewDialog:function(f){var h=b.chain(f).filter(function(j){return j.showCreateReview}).pluck("instance").value();var i=false;if(h.length){var e=require("jira/devstatus/create-review-form-dialog");this.createReviewDialog=new e({analytics:this.analytics,applicationType:this._getActiveApplicationType(),issueId:this.issueId,instances:h});i=true}var g=c.get("fusion-open-detail-dialog");if(JIRA.DevStatus.URL.isCreateReviewDetailDialogLink(g)&&JIRA.DevStatus.URL.getCreateReviewDetailDialogApplicationType(g)===this._getActiveApplicationType()){c.set("fusion-open-detail-dialog",undefined);if(i){this.createReviewDialog.dialog.show()}}return i},_tooltipSeq:1,_onHoverReviewsToolTip:function(g){var f=this;this._setupReviewsPopup(g,function(e){return f._getCommitDetails(e).reviews},function(){JIRA.DevStatus.CommitsAnalytics.fireDetailReviewsShown(f._getActiveApplicationType())},function(){f._onClickReview(g)})},_onClickReviewsToolTip:function(f){if(this.activeReviewsToolTip){f.stopPropagation()}},setupBranchesTooltip:function(){var e=this;d(".branches-link").tooltip({title:function(){var f=e._getCommitDetails(d(this)).branches;JIRA.DevStatus.CommitsAnalytics.fireDetailBranchesShown(e._getActiveApplicationType());return JIRA.Templates.DevStatus.DetailDialog.branchesTooltip({branchData:f})},html:true})},getTitle:function(h,f){var e=b.chain(this.model.get("tabs")).map(function(i){return i.count}).reduce(function(i,j){return i+j},0).value();var g=Math.max(e-h,0);return d.trim(AJS.format("{1}: {0} unique {0,choice,1#commit|1\u003ccommits}{2,choice,0# |0\u003c (and {2} duplicates)}",h,f,g))},getOAuthMessageInFooter:function(e){return AJS.format("You might be able to see more commits by authenticating with the following {0,choice,1#application|1\u003capplications}:",e.length)},getOAuthMessageInCanvas:function(){return "Authenticate to see related commits"},getConnectionMessageInCanvas:function(){return "Unable to retrieve commit information"},getNoPermissionToViewAllMessageInCanvas:function(){return "You don\'t have access to view all related commits."},hasData:function(e){return this.concatResults(e).length>0},transformRepositories:function(f){f=this.sortRepositoriesAndCommits(f);var e=this;var g=[["reviews","showReviews"],["branches","showBranches"],["files","showFiles"],["createReviewUrl","showCreateReview"]];b.each(g,function(h){f=e._setRepositoryFromFromCommitField(f,h[0],h[1])});f=this.prepareReviews(f);return f},_setRepositoryFromFromCommitField:function(f,g,e){b.each(f,function(h){h[e]=b.find(h.commits,function(i){return i[g]!=null})!=null});return f},prepareReviews:function(f){var e=this;b.each(f,function(g){b.each(g.commits,e._orderCommitReviews,e)});return f},_orderCommitReviews:function(e){if(e.reviews&&e.reviews.reviews){e.reviews.reviews=this._sortReviewsByStatus(e.reviews.reviews)}},sortRepositoriesAndCommits:function(e){e=b.sortBy(e,function(f){return f.name.toLowerCase()});b.each(e,function(f){f.commits=b.sortBy(f.commits,"authorTimestamp").reverse()});return e},getUniqueCommitCount:function(e){return b.union.apply(null,b.map(e,function(f){return b.filter(b.pluck(f.commits,"id"),function(g){return g})})).length},_getRepoDetails:function(e){return this.transformedRepositories[parseInt(e.parents(".detail-commits-container").data("repository-index"))]},_getCommitDetails:function(e){return this._getRepoDetails(e).commits[parseInt(e.parents("tr").data("commit-index"))]},_onClickRepositoryLink:function(){JIRA.DevStatus.CommitsAnalytics.fireDetailRepoClicked(this._getActiveApplicationType())},_onClickChangesetId:function(){JIRA.DevStatus.CommitsAnalytics.fireDetailCommitClicked(this._getActiveApplicationType())},_onClickExpand:function(g){g.preventDefault();var f=this._getFileExpand(d(g.target));if(f.toggle(f.getRows())){JIRA.DevStatus.CommitsAnalytics.fireDetailFilesExpandedClicked(this._getActiveApplicationType())}this._clipEllipsis()},_onClickFiles:function(g){g.preventDefault();var f=this._getFileExpand(d(g.target)).toggle(d(g.target).closest(".commitrow").next(".filerow"));this._clipEllipsis();if(f){JIRA.DevStatus.CommitsAnalytics.fireDetailFileExpandedClicked(this._getActiveApplicationType())}},_onClickCreateReview:function(){JIRA.DevStatus.CommitsAnalytics.fireDetailCreateReviewClicked(this._getActiveApplicationType(),false)},_onClickReview:function(){JIRA.DevStatus.CommitsAnalytics.fireDetailReviewClicked(this._getActiveApplicationType())},_onClickFile:function(){JIRA.DevStatus.CommitsAnalytics.fireDetailFileClicked(this._getActiveApplicationType())},_getFileExpand:function(e){var g=e.closest(".detail-commits-container");function f(h){return h.length>h.filter(".hidden").length}return{getRows:function(){return g.find(".filerow")},toggle:function(i){var h=f(i);i.toggleClass("hidden",h);this._updateExpandLabel();return !h},_updateExpandLabel:function(){g.find(".file-expand a").text(f(this.getRows())?"Hide files":"Show all files")}}}})});Backbone.define("JIRA.DevStatus.DetailDialogCommitView",require("jira/devstatus/detail-dialog-commit-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/DetailDialogBranchView.js' */
define("jira/devstatus/detail-dialog-branch-view",["jquery","underscore","jira/devstatus/base-detail-dialog-view"],function(c,b,a){return a.extend({template:JIRA.Templates.DevStatus.DetailDialog.branch,pullRequestToolTipTemplate:JIRA.Templates.DevStatus.DetailDialog.pullRequestToolTip,STATE_ORDER:["OPEN","MERGED","DECLINED"],events:{"click a.repository-link":"_onClickRepositoryLink","click a.branch-link":"_onClickBranchLink","click a.pullrequest-link":"_onClickPullRequestLink","click a.create-pullrequest-link":"_onClickCreatePullRequestLink","click a.create-review-link":"_onClickCreateReviewLink","mouseenter .pullrequest-tooltip":"_onHoverPullRequestsToolTip","mouseenter .review-link":"_onHoverReviewsToolTip","click .pullrequest-tooltip":"_onClickPullRequestsToolTip"},initialize:function(d){this.analyticIssueData=d.analyticIssueData||{};this.analytics=JIRA.DevStatus.BranchesAnalytics;a.prototype.initialize.call(this,b.extend({},d,{type:"branch",width:1000,height:400,dataType:"pullrequest"}))},renderSuccess:function(j,d){var f=this._sortBranchesByName(this._removeWithNoRepos(this._extractAllBranches(d)));var i=this._extractAllPullRequests(d);this._populatePullRequestStateByBranch(f,i);this._prepareBranchReviews(f);var g=this._getBranchFeatures(f);var h=this._getBranchCount(f);var e=this.getContentContainer(j);if(h>0){e.html(this.template({applicationType:j,branches:f,features:g,branchCount:h}));JIRA.DevStatus.Date.addTooltip(e)}else{e.empty()}this.renderNoPermissionToViewAllWarningAtBottom(j,h);return this},getTitle:function(e,d){return AJS.format("{1}: {0} {0,choice,1#branch|1\u003cbranches}",e,d)},getOAuthMessageInFooter:function(d){return AJS.format("You might be able to see more branches by authenticating with the following {0,choice,1#application|1\u003capplications}:",d.length)},getOAuthMessageInCanvas:function(){return "Authenticate to see related branches"},getConnectionMessageInCanvas:function(){return "Unable to retrieve branch information"},getNoPermissionToViewAllMessageInCanvas:function(){return "You don\'t have access to view all related branches."},hasData:function(d){return this._removeWithNoRepos(this._extractAllBranches(d)).length>0},_extractAllBranches:function(d){return b.compact(b.flatten(b.pluck(d,"branches")))},_getBranchFeatures:function(d){return{pullRequests:b.find(d,function(e){return e.createPullRequestUrl||(e.pullRequestState&&e.pullRequestState.total)})!=null,lastCommitId:b.find(d,function(e){return e.lastCommit&&e.lastCommit.displayId})!=null,lastCommitTimestamp:b.find(d,function(e){return e.lastCommit&&e.lastCommit.authorTimestamp})!=null,reviews:b.find(d,function(e){return e.createReviewUrl||(e.reviews&&e.reviews.totalCount)})!=null}},_removeWithNoRepos:function(d){return b.filter(d,function(e){return e.repository})},_prepareBranchReviews:function(e){var d=this._sortReviewsByStatus;b.each(e,function(f){if(f.reviews){if(f.reviews.reviews){f.reviews.reviews=d(f.reviews.reviews)}f.reviews.json=JSON.stringify(f.reviews)}})},_extractAllPullRequests:function(d){return b.flatten(b.compact(b.pluck(d,"pullRequests")))},_sortBranchesByName:function(d){return b.sortBy(d,function(e){return e.repository.name+e.name})},_onClickRepositoryLink:function(){this.analytics.fireDetailRepoClicked(this._getActiveApplicationType())},_onClickBranchLink:function(){this.analytics.fireDetailBranchClicked(this._getActiveApplicationType())},_onClickPullRequestLink:function(){this.analytics.fireDetailPullRequestLozengeClick(this._getActiveApplicationType())},_onClickCreatePullRequestLink:function(){this.analytics.fireDetailCreatePullRequestClicked(this._getActiveApplicationType(),this.analyticIssueData.isAssignee,this.analyticIssueData.isAssignable)},_onClickCreateReviewLink:function(){this.analytics.fireDetailCreateReviewClicked(this._getActiveApplicationType(),this.analyticIssueData.isAssignee,this.analyticIssueData.isAssignable)},_tooltipSeq:1,_onHoverPullRequestsToolTip:function(g){g.preventDefault();var d=this;var f=c(g.currentTarget);if(!f.data("inline-dialog-inited")){var h="pullrequest-tooltip-"+(this._tooltipSeq++);this.activePullRequestsToolTip=AJS.InlineDialog(f,h,function(j,i,k){var e=c(i);j.html(d.pullRequestToolTipTemplate({pullRequests:e.data("detail")}));d.activePullRequestsToolTip.$content=j;k()},{onHover:true,hideDelay:200,showDelay:50,offsetX:-200,cacheContent:false,width:400});f.data("inline-dialog-inited",true).trigger("mouseenter")}},_onHoverReviewsToolTip:function(f){var d=this;this._setupReviewsPopup(f,function(e){return e.closest("a").data("detail")},undefined,function(){d.analytics.fireDetailReviewLozengeClick(d._getActiveApplicationType())})},_onClickPullRequestsToolTip:function(d){if(this.activePullRequestsToolTip){d.stopPropagation()}},_getBranchCount:function(d){return d.length},_populatePullRequestStateByBranch:function(e,f){var d=this;b.each(e,function(g){var h=b.filter(f,function(i){return i.source.url===g.url});g.pullRequestState=d._summarisePullRequestState(h)});return e},_sortPullRequestsByStatus:function(d){return b.sortBy(d,function(e){return(e.status==="OPEN"?"2":(e.status==="MERGED"?"1":"0"))+e.lastUpdated}).reverse()},_getFirstStatusWithCount:function(d){return b.find(this.STATE_ORDER,function(e){return d[e]})},_summarisePullRequestState:function(d){var e=b.groupBy(d,function(f){return f.status});return{status:this._getFirstStatusWithCount(e),data:JSON.stringify(this._sortPullRequestsByStatus(d)),total:b.size(d)}}})});Backbone.define("JIRA.DevStatus.DetailDialogBranchView",require("jira/devstatus/detail-dialog-branch-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/DetailDialogPullRequestView.js' */
define("jira/devstatus/detail-dialog-pull-request-view",["underscore","jira/devstatus/base-detail-dialog-view"],function(b,a){return a.extend({template:JIRA.Templates.DevStatus.DetailDialog.pullRequest,extraReviewersToolTipTemplate:JIRA.Templates.DevStatus.DetailDialog.extraReviewersTooltip,events:{"click a.pullrequest-link":"_onClickPullRequestLink"},initialize:function(c){this.analytics=JIRA.DevStatus.PullRequestsAnalytics;a.prototype.initialize.call(this,b.extend({type:"pullrequest",width:1000,height:400},c))},renderSuccess:function(h,c){var f=this._removeAuthorFromReviewers(this._extractAllPullRequests(c));var g=this._getSortedPullRequestsByDate(f);var e=b.size(g);var d=this.getContentContainer(h);if(e>0){d.html(this.template({pullRequests:g,pullRequestCount:e,reviewersThreshold:this.options.reviewersThreshold}));this._createReviewersInlineDialog();JIRA.DevStatus.Date.addTooltip(d)}else{d.empty()}this.renderNoPermissionToViewAllWarningAtBottom(h,e);return this},getTitle:function(d,c){return AJS.format("{1}: {0} {0,choice,1#pull request|1\u003cpull requests}",d,c)},getOAuthMessageInFooter:function(c){return AJS.format("You might be able to see more pull requests by authenticating with the following {0,choice,1#application|1\u003capplications}:",c.length)},getOAuthMessageInCanvas:function(){return "Authenticate to see related pull requests"},getConnectionMessageInCanvas:function(){return "Unable to retrieve pull request information"},getNoPermissionToViewAllMessageInCanvas:function(){return "You don\'t have access to view all related pull requests."},hasData:function(c){return this._extractAllPullRequests(c).length>0},_extractAllPullRequests:function(c){return b.compact(b.flatten(b.pluck(c,"pullRequests")))},_removeAuthorFromReviewers:function(c){return b.map(c,function(f){if(f.reviewers&&f.author){var e=b.filter(f.reviewers,function(g){return g.name!=f.author.name});if(f.reviewers.length==e.length){return f}var d=b.clone(f);d.reviewers=e;return d}return f})},_sortReviewers:function(d){var c=this.options.reviewersThreshold;b.each(d,function(f,e){if(b.size(f.reviewers)>0){f.reviewers=b.sortBy(b.filter(f.reviewers,function(g){return g.name}),function(g){return g.approved?"0"+g.name:"1"+g.name});if(f.reviewers.length>c+1){f.extraReviewers=JSON.stringify(f.reviewers.slice(c))}}})},_getSortedPullRequestsByDate:function(c){this._sortReviewers(c);return b.sortBy(c,"lastUpdate").reverse()},_onClickPullRequestLink:function(){this.analytics.fireDetailPullRequestClicked(this._getActiveApplicationType())}})});Backbone.define("JIRA.DevStatus.DetailDialogPullRequestView",require("jira/devstatus/detail-dialog-pull-request-view"));;
;
/* module-key = 'com.atlassian.jira.plugins.jira-development-integration-plugin:devstatus-dialog-all-resources', location = 'js/viewissue/dialog/DetailDialogReviewView.js' */
define("jira/devstatus/detail-dialog-review-view",["underscore","jira/devstatus/base-detail-dialog-view"],function(b,a){return a.extend({template:JIRA.Templates.DevStatus.DetailDialog.review,events:{"click a.review-link":"_onClickReviewLink","click a.comment-link":"_onClickReviewLink"},initialize:function(c){this.analytics=JIRA.DevStatus.ReviewsAnalytics;this.finalStates=["REJECTED","CLOSED"];this.nonFinalStates=["REVIEW","APPROVAL","SUMMARIZE"];this.validStates=b.union(this.finalStates,this.nonFinalStates);a.prototype.initialize.call(this,b.extend({type:"review",width:1000,height:400},c))},_updateReviewers:function(c){c.reviewers=b.chain(c.reviewers).filter(function(d){if(d&&c.author&&c.author.name&&d.name){return !b.isEqual(d.name,c.author.name)}return true}).sortBy(function(d){return(d.complete?"0":"1")+d.name}).map(function(d){d.approved=d.complete;return d}).value();if(c.moderator&&!b.isEqual(c.moderator,c.author)){c.reviewers=[b.extend(c.moderator,{name:"Moderator:"+" "+c.moderator.name})].concat(c.reviewers)}return c},_updateReview:function(c){return function(d){if(d.state&&d.dueDate&&b.contains(c,d.state)){delete d.dueDate}if(d.dueDate&&moment(d.dueDate).isBefore(moment())){d.overDue=true}return d}},_addExtraReviewersJson:function(c){return function(d){if(d.reviewers){d.extraReviewers=JSON.stringify(d.reviewers.slice(c))}return d}},_reviewCompare:function(d,c){if(d.dueDate&&!c.dueDate){return -1}else{if(!d.dueDate&&c.dueDate){return 1}else{if(d.dueDate&&c.dueDate){return d.dueDate.localeCompare(c.dueDate)}else{if(d.lastModified&&c.lastModified){return c.lastModified.localeCompare(d.lastModified)}}}}return 0},_mergeInstanceData:function(c,d){return c.concat(d.reviews||[])},_prepareReviews:function(d){var c=this;return b.chain(d).reduce(this._mergeInstanceData,[]).filter(function(e){e.state=e.state&&e.state.toUpperCase();return b.contains(c.validStates,e.state)}).map(b.compose(this._addExtraReviewersJson(this.options.reviewersThreshold),this._updateReviewers,this._updateReview(this.finalStates))).sort(this._reviewCompare).value()},renderSuccess:function(f,c){var e=this._prepareReviews(c),d=this.getContentContainer(f);if(e.length>0){d.html(this.template({applicationType:f,reviews:e,reviewersThreshold:this.options.reviewersThreshold}));this._createReviewersInlineDialog();JIRA.DevStatus.Date.addTooltip(d)}else{d.empty()}this.renderNoPermissionToViewAllWarningAtBottom(f,e.length);return this},getTitle:function(d,c){return AJS.format("{1}: {0} {0,choice,1#review|1\u003creviews}",d,c)},getNoPermissionToViewAllMessageInCanvas:function(){return "You don\'t have access to view all related reviews."},getOAuthMessageInCanvas:function(){return "Authenticate to see related reviews"},getOAuthMessageInFooter:function(c){return AJS.format("You might be able to see more reviews by authenticating with the following {0,choice,1#application|1\u003capplications}:",c.length)},getConnectionMessageInCanvas:function(){return "Unable to retrieve review information"},hasData:function(c){return b.flatten(b.pluck(c,"reviews"),true).length>0},_onClickReviewLink:function(){this.analytics.fireDetailReviewClicked()}})});Backbone.define("JIRA.DevStatus.DetailDialogReviewView",require("jira/devstatus/detail-dialog-review-view"));;