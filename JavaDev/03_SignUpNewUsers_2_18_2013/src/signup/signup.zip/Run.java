package signup;

public class Run {

	public static void main(String[] args) {

		TheTest setUpNewUsers = new TheTest();
		
		setUpNewUsers.getDataAndSetupNewUsers(1);

	}

}
