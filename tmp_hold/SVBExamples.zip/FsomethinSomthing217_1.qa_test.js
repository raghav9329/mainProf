// involves: login & nav to make payment. make a payment.  No Nickname given at the end.  
//  -1.0 ricksanchez newpas1*  Does this user have links .  That’s what the test is about
//  -1.1 Are there other users who can meet the same requirement showing links ??
// Identify the ticket numbers represented in this ticket.

"use strict";

var specHelper = require("../utils/intSpecHelper");
var envConfig = specHelper.getConfig();
var enUK = require('../../app/src/assets/js/locales/enUK');
var makePaymentPage = require("../pageObjects/MakePaymentPage.js");




/*

 it("should

 */