These are not *.jsx files.  They are *.js file that I added an X to 
inorder to make them different some how.

I don't remember exactly what or why, but I just needed to get these
out of the directory and into a single file / archive.....

4/28/17  Mark