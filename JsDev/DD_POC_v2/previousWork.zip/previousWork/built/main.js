/**
 * Requiring protractor as a node module. Export the contents of the protractor
 * namespace.
 */
"use strict";
module.exports = require('./ptor').protractor;
