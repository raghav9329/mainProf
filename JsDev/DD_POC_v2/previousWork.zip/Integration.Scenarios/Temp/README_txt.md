
   ** Note : **
No body should delete files from this temp directory ( or other temp directories)
Unless !!_they_know_!! they are the only person who put the file there
         ***********
in the first place. 

Also, Temp should be that, Temp.  Not,  the simple garbage.

Temp means you still need this file but maybe you need it out of the way.
 