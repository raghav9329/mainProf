package day2;

import org.openqa.selenium.chrome.ChromeDriver;

public class TestChrome {

	public static void main(String[] args) {
		//in order to continue a system.properties value must be set
		// it needs to be the chromeDriver.exe file that gets downloaded
		// and sits in a drectory. this type file exists for win max lin etc.
		//48:20 in the vid
		
		ChromeDriver d1 = new ChromeDriver();

	}

}
