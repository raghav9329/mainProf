package day2;

public class Static_and_nonStatic {
	
	int x;
	static String z;
	
	public void calcSum(int a, int b){
		
		
	}
	
	

	public static void main(String[] args) {
		System.out.println("Selenium");

	}

}
