package day3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selenium_Example {

	public static void main(String[] args) {
		
		//FirefoxDriver d1 = new FirefoxDriver();
		String bName = "Mozilla";
		//WebDriver driver = new FirefoxDriver();
		WebDriver driver = null;
		System.out.println("Done");
		
	}


}
