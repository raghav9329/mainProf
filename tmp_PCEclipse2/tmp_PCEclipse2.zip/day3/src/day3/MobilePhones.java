package day3;

public interface MobilePhones {
	
	public void call();
	public void recharg();
	public void answer();

}
